"""Read CIHI risk-adjusted urgent readmission rates and retain their source rows.

Place the source files listed in SOURCES in --raw-dir before running.
"""

import argparse
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile
import re
from lxml import etree
from openpyxl.utils.datetime import from_excel

SOURCES = {
    "cihi_indicators.xlsx": "https://www.cihi.ca/sites/default/files/document/indicator-library-indicator-data-no-breakdowns-en.xlsx"
}
FIELDS = [
    "indicator",
    "dimension",
    "period",
    "group",
    "value",
    "unit",
    "ci_lower",
    "ci_upper",
    "status",
    "source_ref",
    "source_id",
    "source_url",
    "note",
]

GROUPS = {
    "All Patients Readmitted to Hospital": "Overall",
    "Medical Patients Readmitted to Hospital": "Medical",
    "Surgical Patients Readmitted to Hospital": "Surgical",
    "Pediatric Patients Readmitted to Hospital": "Pediatric",
    "Obstetric Patients Readmitted to Hospital": "Obstetric",
}


def numeric(value):
    try:
        return float(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return None


def row(
    indicator,
    dimension,
    period,
    group,
    value,
    unit,
    lower,
    upper,
    status,
    source_ref,
    source_id,
    source_url,
    note="",
):
    assert status != "Published" or value is not None
    return {
        "indicator": indicator,
        "dimension": dimension,
        "period": period,
        "group": group,
        "value": value,
        "unit": unit,
        "ci_lower": lower,
        "ci_upper": upper,
        "status": status,
        "source_ref": source_ref,
        "source_id": source_id,
        "source_url": source_url,
        "note": note,
    }


def readmissions(raw: Path):
    """Scan XLSX shared strings and rows without holding the 491k-row workbook in memory."""
    namespace = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"

    def cell_value(c, shared):
        v = c.find(namespace + "v")
        return "" if v is None else shared[int(v.text)] if c.get("t") == "s" else v.text

    output = []
    with ZipFile(raw / "cihi_indicators.xlsx") as archive:
        shared = [
            "".join(si.itertext()) for si in etree.fromstring(archive.read("xl/sharedStrings.xml"))
        ]
        indicator_ids = {str(i): s for i, s in enumerate(shared) if s in GROUPS}
        with archive.open("xl/worksheets/sheet1.xml") as sheet:
            for _, item in etree.iterparse(sheet, events=("end",), tag=namespace + "row"):
                r = item.get("r")
                name_element = item.find(f"{namespace}c[@r='F{r}']/{namespace}v")
                if name_element is not None and name_element.text in indicator_ids:
                    fields = {re.sub(r"\d+", "", c.get("r")): cell_value(c, shared) for c in item}
                    if (
                        fields.get("L") == "Risk-adjusted rate"
                        and fields.get("M") == "Yes"
                        and fields.get("J") == "Not applicable"
                    ):
                        level = fields.get("E")
                        province = fields.get("B")
                        group = GROUPS[fields["F"]]
                        eligible = level in {"National", "Province/territory"}
                        eligible |= (
                            group == "Overall"
                            and province == "Manitoba"
                            and level == "Health region"
                        )
                        eligible |= (
                            group == "Overall"
                            and province == "Manitoba"
                            and level == "Facility"
                            and any(
                                k in fields.get("W", "") for k in ("Teaching", "Medium", "Large")
                            )
                        )
                        if eligible:
                            raw_value = fields.get("N", "")
                            val = numeric(raw_value)
                            status = (
                                "Published" if val is not None else raw_value or "Not available"
                            )
                            note = fields.get("Y", "")
                            if fields.get("W") not in ("", "-", None):
                                note = "; ".join(
                                    filter(None, [note, fields["W"].replace(" ¿ ", " · ")])
                                )
                            if fields.get("T") not in ("", "-", "Suppressed", None):
                                note = "; ".join(filter(None, [note, fields["T"]]))
                            if fields.get("AA") not in ("", "-", None):
                                note = "; ".join(
                                    filter(None, [note, "CIHI trend note: " + fields["AA"]])
                                )
                            refresh = fields.get("AB")
                            if refresh and numeric(refresh) is not None:
                                refresh = from_excel(float(refresh)).date().isoformat()
                            note = "; ".join(
                                filter(None, [note, "Workbook refresh " + str(refresh)])
                            )
                            dimension = {
                                "National": "national",
                                "Province/territory": "province",
                                "Health region": "mb_region",
                                "Facility": "mb_facility",
                            }[level]
                            output.append(
                                row(
                                    group,
                                    dimension,
                                    fields["I"],
                                    fields["A"].replace(" (Man.)", ""),
                                    val,
                                    "per 100 episodes",
                                    numeric(fields.get("P")),
                                    numeric(fields.get("Q")),
                                    status,
                                    "Sheet1 row " + r,
                                    "CIHI Indicator Library · no breakdowns",
                                    SOURCES["cihi_indicators.xlsx"],
                                    note,
                                )
                            )
                item.clear()
                while item.getprevious() is not None:
                    del item.getparent()[0]
    return sorted(output, key=lambda r: (r["dimension"], r["indicator"], r["period"], r["group"]))


PROJECT_NAME = "readmissions"


def source_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_project(name, raw, output):
    files = list(SOURCES)
    target = output / name
    target.mkdir(parents=True, exist_ok=True)
    records = readmissions(raw)
    assert records
    keys = [(r["indicator"], r["dimension"], r["period"], r["group"]) for r in records]
    assert len(keys) == len(set(keys)), "Duplicate observation"
    for r in records:
        val = r["value"]
        if val is not None:
            assert val >= 0 and (r["unit"] != "percent" or val <= 100)
            if r["ci_lower"] is not None and r["ci_upper"] is not None:
                assert r["ci_lower"] - 0.06 <= val <= r["ci_upper"] + 0.06, r
        elif r["status"] in ("Published", "Use with caution"):
            raise ValueError(r)
    with (target / "data.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)
    manifest = {
        "project": name,
        "sources": [
            {
                "filename": f,
                "url": SOURCES[f],
                "size_bytes": (raw / f).stat().st_size,
                "sha256": source_hash(raw / f),
            }
            for f in files
        ],
        "observations": len(records),
        "published_numeric": sum(r["value"] is not None for r in records),
        "quality_caution": sum(r["status"] == "Use with caution" for r in records),
        "unavailable_or_suppressed": sum(r["value"] is None for r in records),
    }
    (target / "source_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(
        name,
        manifest["observations"],
        "rows;",
        manifest["published_numeric"],
        "numeric;",
        manifest["unavailable_or_suppressed"],
        "withheld",
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--project", choices=["all", PROJECT_NAME], default="all")
    args = parser.parse_args()
    write_project(PROJECT_NAME, args.raw_dir, args.output_dir)
