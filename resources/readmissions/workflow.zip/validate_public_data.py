"""Match normalized rows to the original source files using an independent reader."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import openpyxl
from extract_public_data import PROJECT_NAME, GROUPS, numeric


def read(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def equal_float(left, right):
    return numeric(left) == numeric(right)


def verify_cihi(raw, rows):
    desired = {int(r["source_ref"].split()[-1]): r for r in rows}
    observed = set()
    w = openpyxl.load_workbook(raw / "cihi_indicators.xlsx", read_only=True, data_only=True)
    for i, v in enumerate(w["Sheet1"].iter_rows(values_only=True), 1):
        if i == 1:
            continue
        if (
            v[5] not in GROUPS
            or v[11] != "Risk-adjusted rate"
            or v[12] != "Yes"
            or v[9] != "Not applicable"
        ):
            continue
        level = v[4]
        province = v[1]
        include = level in ("National", "Province/territory") or (
            v[5] == "All Patients Readmitted to Hospital"
            and province == "Manitoba"
            and (
                level == "Health region"
                or level == "Facility"
                and any(a in (v[22] or "") for a in ("Teaching", "Medium", "Large"))
            )
        )
        if not include:
            continue
        assert i in desired, ("missing CIHI row", i)
        r = desired[i]
        observed.add(i)
        assert r["indicator"] == GROUPS[v[5]]
        assert r["period"] == v[8] and r["group"] == v[0].replace(" (Man.)", "")
        assert (
            r["dimension"]
            == {
                "National": "national",
                "Province/territory": "province",
                "Health region": "mb_region",
                "Facility": "mb_facility",
            }[level]
        )
        assert (
            equal_float(r["value"], v[13])
            and equal_float(r["ci_lower"], v[15])
            and equal_float(r["ci_upper"], v[16])
        ), (i, r, v[13:17])
        assert r["status"] == (
            "Published" if numeric(v[13]) is not None else v[13] or "Not available"
        )
    w.close()
    assert observed == set(desired)
    return len(observed)


def validate_project(name, raw, data):
    target = data / name
    rows = read(target / "data.csv")
    manifest = json.loads((target / "source_manifest.json").read_text())
    for source in manifest["sources"]:
        with (raw / source["filename"]).open("rb") as f:
            assert hashlib.file_digest(f, "sha256").hexdigest() == source["sha256"]
    detail = {"CIHI workbook row and inclusion scope": verify_cihi(raw, rows)}
    assert sum(detail.values()) == len(rows)
    result = {
        "project": name,
        "status": "passed",
        "source_rows_verified": len(rows),
        "checks": detail,
        "note": "All normalized source observations matched independent source checks. Withheld estimates remain blank.",
    }
    (target / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(name, result, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--project", choices=["all", PROJECT_NAME], default="all")
    args = parser.parse_args()
    validate_project(PROJECT_NAME, args.raw_dir, args.data_dir)
