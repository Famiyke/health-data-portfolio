"""Match normalized rows to the original source files using an independent reader."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile
from extract_public_data import PROJECT_NAME, FLAGS, SOURCE_FILE, MB_INDICATORS, numeric


def read(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def verify_statcan(raw, code, rows):
    # Use source period + estimate vector, then verify confidence bounds from the source coordinate.
    desired = {(r["period"], r["source_ref"].split(" · ")[0]): r for r in rows}
    target_coordinates = {
        (r["period"], r["source_ref"].split(" · ")[1].rsplit(".", 1)[0]): r for r in rows
    }
    seen = set()
    ci = {}
    with ZipFile(raw / SOURCE_FILE[code]) as z, z.open(code + ".csv") as rawfile:
        import io

        reader = csv.DictReader(io.TextIOWrapper(rawfile, encoding="utf-8-sig", newline=""))
        for line in reader:
            if line["Characteristics"] == "Percent":
                key = (line["REF_DATE"], line["VECTOR"])
                if key not in desired:
                    continue
                r = desired[key]
                seen.add(key)
                assert line["COORDINATE"] == r["source_ref"].split(" · ")[1]
                assert r["indicator"] == MB_INDICATORS[line["Indicators"]]
                assert (
                    line["Age group"] == "Total, 18 years and over" and line["Sex"] == "Both sexes"
                )
                assert r["group"] == line["GEO"].removesuffix(", Manitoba")
                assert r["dimension"] == (
                    "province_survey" if line["GEO"] == "Manitoba" else "region_survey"
                )
                assert r["status"] == FLAGS[line["STATUS"]]
                val = numeric(line["VALUE"]) if line["STATUS"] in ("", "E") else None
                assert numeric(r["value"]) == val
            elif line["Characteristics"] in [
                "Low 95% confidence interval, percent",
                "High 95% confidence interval, percent",
            ]:
                ckey = (line["REF_DATE"], line["COORDINATE"].rsplit(".", 1)[0])
                if ckey not in target_coordinates:
                    continue
                field = "ci_lower" if line["Characteristics"].startswith("Low") else "ci_upper"
                val = numeric(line["VALUE"]) if line["STATUS"] in ("", "E") else None
                assert numeric(target_coordinates[ckey][field]) == val
                ci[(ckey, field)] = True
    assert seen == set(desired)
    for key, r in target_coordinates.items():
        for field in ("ci_lower", "ci_upper"):
            if r[field]:
                assert (key, field) in ci, (key, field)
    return len(seen)


def verify_manitoba_report(rows):
    # Independently transcribed from the report's exact printed labels (pages 95, 116–118, 126, 128, 130).
    order = [
        "Interlake-Eastern",
        "Northern",
        "Prairie Mountain",
        "Southern Health–Santé Sud",
        "Winnipeg",
    ]
    observed = {(r["indicator"], r["dimension"], r["group"]): float(r["value"]) for r in rows}
    expected = {}

    def region(name, values):
        expected.update({(name, "region_admin", g): v for g, v in zip(order, values)})

    region("Heart attack hospitalizations and deaths", [3.22, 5.39, 3.09, 3.19, 2.25])
    region("Stroke hospitalizations and deaths", [2.15, 2.99, 2.00, 2.53, 2.32])
    region("Unintentional injury hospitalizations", [786.51, 938.77, 831.92, 601.03, 655.25])
    region("Fall-related hospitalizations", [442.4, 502.4, 459.3, 316.7, 375.8])
    region("Transport-related fatalities", [8.74, 11.56, 10.20, 7.64, 3.81])
    for setting, values in [
        ("Rural", [621, 638, 524, 475, 428]),
        ("Urban", [465, 320, 264, 240, 209]),
    ]:
        for i, v in enumerate(values, 1):
            expected[("Emergency department visits", "income", f"{setting} quintile {i}")] = v
    expected.update(
        {
            ("Residents admitted to hospital at least once", "income", "Rural 1 (lowest)"): 6.99,
            ("Residents admitted to hospital at least once", "income", "Urban 5 (highest)"): 3.75,
        }
    )
    for name, vals in [
        ("Heart attack hospitalizations and deaths", [3.92, 2.63, 3.04, 1.6]),
        ("Stroke hospitalizations and deaths", [2.54, 1.92, 2.70, 1.52]),
    ]:
        for group, v in zip(["Rural 1 (lowest)", "Rural 5 (highest)", "Urban 1", "Urban 5"], vals):
            expected[(name, "income", group)] = v
    assert observed == expected, (
        set(observed.items()) - set(expected.items()),
        set(expected.items()) - set(observed.items()),
    )
    return len(observed)


def validate_project(name, raw, data):
    target = data / name
    rows = read(target / "data.csv")
    manifest = json.loads((target / "source_manifest.json").read_text())
    for source in manifest["sources"]:
        with (raw / source["filename"]).open("rb") as f:
            assert hashlib.file_digest(f, "sha256").hexdigest() == source["sha256"]
    survey_rows = [row for row in rows if "Statistics Canada" in row["source_id"]]
    report_rows = [row for row in rows if "Manitoba Health ·" in row["source_id"]]
    detail = {
        "Statistics Canada 13-10-0972-01": verify_statcan(raw, "13100972", survey_rows),
        "Manitoba Health report figure/label transcription": verify_manitoba_report(report_rows),
    }
    assert sum(detail.values()) == len(rows)
    result = {
        "project": name,
        "status": "passed",
        "source_rows_verified": len(rows),
        "checks": detail,
        "note": "All normalized source observations matched independent source checks. Withheld estimates remain blank.",
    }
    (target / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(name, result, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--project", choices=["all", PROJECT_NAME], default="all")
    args = parser.parse_args()
    validate_project(PROJECT_NAME, args.raw_dir, args.data_dir)
