"""Read regional survey estimates and the explicitly labelled figures in Manitoba’s health status report.

Place the source files listed in SOURCES in --raw-dir before running.
"""

import argparse
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile
import pandas as pd
import re
import subprocess

SOURCES = {
    "statcan_health_13100972.zip": "https://www150.statcan.gc.ca/n1/tbl/csv/13100972-eng.zip",
    "mb_health_status2025.pdf": "https://www.gov.mb.ca/asset_library/en/cppho/docs/health-status-2025.pdf",
}
FIELDS = [
    "indicator",
    "dimension",
    "period",
    "group",
    "value",
    "unit",
    "ci_lower",
    "ci_upper",
    "status",
    "source_ref",
    "source_id",
    "source_url",
    "note",
]

MB_INDICATORS = {
    "Diabetes": "Self-reported diabetes",
    "High blood pressure": "Self-reported high blood pressure",
    "Current smoker, daily or occasional": "Current smoking, daily or occasional",
    "Perceived health, fair or poor": "Fair or poor perceived health",
    "Perceived mental health, fair or poor": "Fair or poor perceived mental health",
    "Mood disorder": "Self-reported mood disorder",
    "Anxiety disorder": "Self-reported anxiety disorder",
}

MB_REGIONS = {
    "IERHA": "Interlake-Eastern",
    "NHR": "Northern",
    "Northern": "Northern",
    "PMH": "Prairie Mountain",
    "SH-SS": "Southern Health–Santé Sud",
    "WRHA": "Winnipeg",
    "MB": "Manitoba",
}

FLAGS = {
    "": "Published",
    "E": "Use with caution",
    "F": "Too unreliable to publish",
    "x": "Suppressed",
    "..": "Not available",
}
SOURCE_TABLE = {"13100972": "Statistics Canada Table 13-10-0972-01"}
SOURCE_FILE = {"13100972": "statcan_health_13100972.zip"}


def numeric(value):
    try:
        return float(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return None


def row(
    indicator,
    dimension,
    period,
    group,
    value,
    unit,
    lower,
    upper,
    status,
    source_ref,
    source_id,
    source_url,
    note="",
):
    assert status != "Published" or value is not None
    return {
        "indicator": indicator,
        "dimension": dimension,
        "period": period,
        "group": group,
        "value": value,
        "unit": unit,
        "ci_lower": lower,
        "ci_upper": upper,
        "status": status,
        "source_ref": source_ref,
        "source_id": source_id,
        "source_url": source_url,
        "note": note,
    }


def statcan_extract(raw: Path, code, indicators, selector, dimension, labels, notes):
    """Join each estimate with published confidence intervals and source vector."""
    cols = [
        "REF_DATE",
        "GEO",
        "Age group",
        "Indicators",
        "Characteristics",
        "VALUE",
        "STATUS",
        "VECTOR",
        "COORDINATE",
    ]
    cols += ["Sex"]
    stats = [
        "Percent",
        "Low 95% confidence interval, percent",
        "High 95% confidence interval, percent",
    ]
    pieces = []
    with ZipFile(raw / SOURCE_FILE[code]) as zipped:
        for d in pd.read_csv(
            zipped.open(code + ".csv"),
            usecols=cols,
            dtype=str,
            keep_default_na=False,
            chunksize=100_000,
        ):
            d = d[d["Indicators"].isin(indicators) & d["Characteristics"].isin(stats)]
            if len(d):
                pieces.append(d.loc[selector(d)])
    data = pd.concat(pieces, ignore_index=True)
    key = [
        c
        for c in ["REF_DATE", "GEO", "Age group", "Sex", "Gender", "Population group", "Indicators"]
        if c in data
    ]
    assert not data.duplicated(key + ["Characteristics"]).any()
    by_key = data.set_index(key + ["Characteristics"])
    result = []
    for _, estimate in data[data.Characteristics == "Percent"].iterrows():
        k = tuple(estimate[c] for c in key)

        def confidence(stat):
            try:
                cv = by_key.loc[k + (stat,)]
                return numeric(cv.VALUE) if cv.STATUS in ("", "E") else None
            except KeyError:
                return None

        val = numeric(estimate.VALUE) if estimate.STATUS in ("", "E") else None
        result.append(
            row(
                indicators[estimate.Indicators],
                dimension(estimate),
                estimate.REF_DATE,
                labels(estimate),
                val,
                "percent",
                confidence(stats[1]),
                confidence(stats[2]),
                FLAGS.get(estimate.STATUS, "Not available"),
                estimate.VECTOR + " · " + estimate.COORDINATE,
                SOURCE_TABLE[code],
                "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=" + code + "01",
                notes(estimate),
            )
        )
    return result


def extract_mb_report(raw: Path):
    """Extract only explicitly printed values from identified pages of the 2025 official report."""
    pages = subprocess.check_output(
        ["pdftotext", "-layout", str(raw / "mb_health_status2025.pdf"), "-"], text=True
    ).split("\f")
    output = []
    source_url = SOURCES["mb_health_status2025.pdf"]
    source_base = "Manitoba Health · A Healthier Manitoba For All (2025), "

    def emit(indicator, dimension, period, group, value, unit, page, note):
        output.append(
            row(
                indicator,
                dimension,
                period,
                group,
                float(value),
                unit,
                None,
                None,
                "Published",
                f"Printed p. {page-4} (PDF p. {page})",
                source_base + f"p. {page-4}",
                source_url + "#page=" + str(page),
                note,
            )
        )

    region_metrics = [
        (
            120,
            "Heart attack hospitalizations and deaths",
            "2018–2022",
            "per 1,000 residents aged 40+",
            "MCHP 2024 RHA Indicators Atlas, reported by Manitoba Health.",
            "RATES OF HEART ATTACK",
        ),
        (
            122,
            "Stroke hospitalizations and deaths",
            "2018–2022",
            "per 1,000 residents aged 40+",
            "MCHP 2024 RHA Indicators Atlas, reported by Manitoba Health.",
            "REGIONAL R ATES OF STROKE",
        ),
        (
            130,
            "Unintentional injury hospitalizations",
            "2023–2024",
            "per 100,000 residents",
            "Manitoba Health administrative report.",
            "2023-24 HOSPITALIZ ATION R ATE",
        ),
        (
            132,
            "Fall-related hospitalizations",
            "2023–2024",
            "per 100,000 residents",
            "Manitoba Health administrative report.",
            "REGIONAL R ATES OF FALL-REL ATED",
        ),
        (
            134,
            "Transport-related fatalities",
            "2022–2023",
            "per 100,000 residents",
            "Manitoba Health administrative report.",
            "NUMBER OF TR ANSPORT-REL ATED",
        ),
    ]
    pattern = re.compile(r"\b(IERHA|NHR|Nor\s*thern|PMH|SH-SS|WRHA)(?:\s+3)?\s{2,}(\d+(?:\.\d+)?)")
    for page, name, period, unit, note, anchor in region_metrics:
        src = pages[page - 1]
        assert anchor in src
        matches = pattern.findall(src)
        values = {}
        for key, val in matches:
            key = "Northern" if "".join(key.split()).lower() == "northern" else key
            assert key in MB_REGIONS
            values[MB_REGIONS[key]] = float(val)
        assert len(values) == 5, (page, values)
        for group, val in values.items():
            emit(name, "region_admin", period, group, val, unit, page, note)
    page = 99
    src = pages[page - 1]
    # ED figure labels R1/R5 and U1/U5 may share a row with textual callouts.
    matches = re.findall(r"\b([RU][1-5])\s+(\d+)\s*$", src, re.M)
    # The figure's two lowest quintile labels wrap below their values; inspect exact lines separately.
    matches += re.findall(r"\b([RU]1)\s*\n\s*\(lowest (?:rural|urban)\)\s+(\d+)", src)
    # The labels sit on vertically separate lines; enforce all ten printed groups.
    vals = dict(matches)
    for code in ["R1", "U1"]:
        if code not in vals:
            m = re.search(r"\b" + code + r"\s*\n\s*\(lowest (?:rural|urban)\)\s+(\d+)", src)
            if m:
                vals[code] = m.group(1)
    assert len(vals) == 10, vals
    for code, val in sorted(vals.items()):
        label = ("Rural" if code[0] == "R" else "Urban") + " quintile " + code[1]
        emit(
            "Emergency department visits",
            "income",
            "2023",
            label,
            val,
            "visits per 1,000 people",
            page,
            "Shared Health Manitoba, reported by Manitoba Health. Q1 = lowest income, Q5 = highest.",
        )
    hosp = re.findall(r"(Rural 1 \(lowest\)|Urban 5 \(highest\))\s+(\d+\.\d+)", src)
    assert len(hosp) == 2
    for label, val in hosp:
        emit(
            "Residents admitted to hospital at least once",
            "income",
            "2022–2023",
            label,
            val,
            "age- and sex-adjusted percent",
            page,
            "Source reports selected income settings, not all ten combinations.",
        )
    for page, name in [
        (121, "Heart attack hospitalizations and deaths"),
        (122, "Stroke hospitalizations and deaths"),
    ]:
        src = pages[page - 1]
        vals = re.findall(
            r"(Rural [15] \((?:highest|lowest)\)|Urban [15])\s+[–-]\s+(\d+(?:\.\d+)?)", src
        )
        assert len(vals) == 4, (page, vals)
        for label, val in vals:
            # The PDF text layer attaches superscript reference 40 to the final 2.70 value.
            # The report's printed value is 2.70, not 2.7040 (confirmed from separate font span).
            if page == 122 and label == "Urban 1":
                assert val in {"2.70", "2.7040"}
                val = "2.70"
            emit(
                name,
                "income",
                "2018–2022",
                label,
                val,
                "per 1,000 residents aged 40+",
                page,
                "MCHP 2024 RHA Indicators Atlas online supplement; Q1 lowest, Q5 highest. Selected income extremes.",
            )
    return output


def manitoba(raw: Path):
    def label(r):
        return r.GEO.removesuffix(", Manitoba")

    out = statcan_extract(
        raw,
        "13100972",
        MB_INDICATORS,
        lambda d: (d.GEO.eq("Manitoba") | d.GEO.str.endswith(", Manitoba"))
        & d["Age group"].eq("Total, 18 years and over")
        & d.Sex.eq("Both sexes"),
        lambda r: "province_survey" if r.GEO == "Manitoba" else "region_survey",
        label,
        lambda r: "CCHS two-year weighted survey estimate; self-reported, adults 18+; both sexes.",
    )
    out += extract_mb_report(raw)
    return sorted(out, key=lambda r: (r["indicator"], r["dimension"], r["period"], r["group"]))


PROJECT_NAME = "manitoba"


def source_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_project(name, raw, output):
    files = list(SOURCES)
    target = output / name
    target.mkdir(parents=True, exist_ok=True)
    records = manitoba(raw)
    assert records
    keys = [(r["indicator"], r["dimension"], r["period"], r["group"]) for r in records]
    assert len(keys) == len(set(keys)), "Duplicate observation"
    for r in records:
        val = r["value"]
        if val is not None:
            assert val >= 0 and (r["unit"] != "percent" or val <= 100)
            if r["ci_lower"] is not None and r["ci_upper"] is not None:
                assert r["ci_lower"] - 0.06 <= val <= r["ci_upper"] + 0.06, r
        elif r["status"] in ("Published", "Use with caution"):
            raise ValueError(r)
    with (target / "data.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)
    manifest = {
        "project": name,
        "sources": [
            {
                "filename": f,
                "url": SOURCES[f],
                "size_bytes": (raw / f).stat().st_size,
                "sha256": source_hash(raw / f),
            }
            for f in files
        ],
        "observations": len(records),
        "published_numeric": sum(r["value"] is not None for r in records),
        "quality_caution": sum(r["status"] == "Use with caution" for r in records),
        "unavailable_or_suppressed": sum(r["value"] is None for r in records),
    }
    (target / "source_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(
        name,
        manifest["observations"],
        "rows;",
        manifest["published_numeric"],
        "numeric;",
        manifest["unavailable_or_suppressed"],
        "withheld",
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--project", choices=["all", PROJECT_NAME], default="all")
    args = parser.parse_args()
    write_project(PROJECT_NAME, args.raw_dir, args.output_dir)
