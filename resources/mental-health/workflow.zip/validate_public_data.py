"""Match normalized rows to the original source files using an independent reader."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile
from extract_public_data import PROJECT_NAME, FLAGS, SOURCE_FILE, MENTAL_INDICATORS, numeric


def read(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def verify_statcan(raw, code, rows):
    # Use source period + estimate vector, then verify confidence bounds from the source coordinate.
    desired = {(r["period"], r["source_ref"].split(" · ")[0]): r for r in rows}
    target_coordinates = {
        (r["period"], r["source_ref"].split(" · ")[1].rsplit(".", 1)[0]): r for r in rows
    }
    seen = set()
    ci = {}
    with ZipFile(raw / SOURCE_FILE[code]) as z, z.open(code + ".csv") as rawfile:
        import io

        reader = csv.DictReader(io.TextIOWrapper(rawfile, encoding="utf-8-sig", newline=""))
        for line in reader:
            if line["Characteristics"] == "Percent":
                key = (line["REF_DATE"], line["VECTOR"])
                if key not in desired:
                    continue
                r = desired[key]
                seen.add(key)
                assert line["COORDINATE"] == r["source_ref"].split(" · ")[1]
                assert r["indicator"] == MENTAL_INDICATORS[line["Indicators"]]
                if code == "13100930":
                    assert (
                        r["dimension"] == "population_group"
                        and r["group"] == line["Population group"]
                    )
                elif r["dimension"] == "age":
                    assert r["group"] == line["Age group"] and line["GEO"] == "Canada"
                elif r["dimension"] == "gender":
                    assert r["group"] == line["Gender"] and line["GEO"] == "Canada"
                else:
                    assert r["group"] == line["GEO"] and r["dimension"] == (
                        "national" if line["GEO"] == "Canada" else "province"
                    )
                assert r["status"] == FLAGS[line["STATUS"]]
                val = numeric(line["VALUE"]) if line["STATUS"] in ("", "E") else None
                assert numeric(r["value"]) == val
            elif line["Characteristics"] in [
                "Low 95% confidence interval, percent",
                "High 95% confidence interval, percent",
            ]:
                ckey = (line["REF_DATE"], line["COORDINATE"].rsplit(".", 1)[0])
                if ckey not in target_coordinates:
                    continue
                field = "ci_lower" if line["Characteristics"].startswith("Low") else "ci_upper"
                val = numeric(line["VALUE"]) if line["STATUS"] in ("", "E") else None
                assert numeric(target_coordinates[ckey][field]) == val
                ci[(ckey, field)] = True
    assert seen == set(desired)
    for key, r in target_coordinates.items():
        for field in ("ci_lower", "ci_upper"):
            if r[field]:
                assert (key, field) in ci, (key, field)
    return len(seen)


def validate_project(name, raw, data):
    target = data / name
    rows = read(target / "data.csv")
    manifest = json.loads((target / "source_manifest.json").read_text())
    for source in manifest["sources"]:
        with (raw / source["filename"]).open("rb") as f:
            assert hashlib.file_digest(f, "sha256").hexdigest() == source["sha256"]
    detail = {}
    for code in ("13100465", "13100930"):
        table_number = f"{code[:2]}-{code[2:4]}-{code[4:]}"
        source_rows = [row for row in rows if table_number in row["source_id"]]
        detail[code] = verify_statcan(raw, code, source_rows)
    assert sum(detail.values()) == len(rows)
    result = {
        "project": name,
        "status": "passed",
        "source_rows_verified": len(rows),
        "checks": detail,
        "note": "All normalized source observations matched independent source checks. Withheld estimates remain blank.",
    }
    (target / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(name, result, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--project", choices=["all", PROJECT_NAME], default="all")
    args = parser.parse_args()
    validate_project(PROJECT_NAME, args.raw_dir, args.data_dir)
