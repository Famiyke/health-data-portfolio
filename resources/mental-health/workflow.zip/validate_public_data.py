"""Independent source-to-output validation using openpyxl and the CSV standard library.

This is intentionally separate from the lxml/pandas extraction implementation.
The PDF figures are checked against independently read labeled values.
"""
from pathlib import Path
from zipfile import ZipFile
import argparse
import csv
import json
import re
import hashlib
import openpyxl
from extract_public_data import PROJECTS, GROUPS, FLAGS, SOURCE_FILE, MENTAL_INDICATORS, MB_INDICATORS, numeric

def read(path):
    with path.open(newline="",encoding="utf-8") as stream:
        return list(csv.DictReader(stream))

def equal_float(left,right):
    return numeric(left)==numeric(right)

def verify_cihi(raw, rows):
    desired={int(r["source_ref"].split()[-1]):r for r in rows}
    observed=set()
    w=openpyxl.load_workbook(raw/"cihi_indicators.xlsx",read_only=True,data_only=True)
    for i,v in enumerate(w["Sheet1"].iter_rows(values_only=True),1):
        if i==1: continue
        if v[5] not in GROUPS or v[11]!="Risk-adjusted rate" or v[12]!="Yes" or v[9]!="Not applicable":
            continue
        level=v[4]; province=v[1]
        include=(level in ("National","Province/territory") or
                 (v[5]=="All Patients Readmitted to Hospital" and province=="Manitoba" and (
                     level=="Health region" or level=="Facility" and any(a in (v[22] or "") for a in ("Teaching","Medium","Large")))))
        if not include: continue
        assert i in desired, ("missing CIHI row",i)
        r=desired[i]; observed.add(i)
        assert r["indicator"]==GROUPS[v[5]]
        assert r["period"]==v[8] and r["group"]==v[0].replace(" (Man.)","")
        assert r["dimension"]=={"National":"national","Province/territory":"province","Health region":"mb_region","Facility":"mb_facility"}[level]
        assert equal_float(r["value"],v[13]) and equal_float(r["ci_lower"],v[15]) and equal_float(r["ci_upper"],v[16]), (i,r,v[13:17])
        assert r["status"]==("Published" if numeric(v[13]) is not None else v[13] or "Not available")
    w.close()
    assert observed==set(desired)
    return len(observed)

def verify_statcan(raw,code,rows):
    # Use source period + estimate vector, then verify confidence bounds from the source coordinate.
    desired={(r["period"],r["source_ref"].split(" · ")[0]):r for r in rows}
    target_coordinates={(r["period"],r["source_ref"].split(" · ")[1].rsplit(".",1)[0]):r for r in rows}
    seen=set(); ci={}
    with ZipFile(raw/SOURCE_FILE[code]) as z, z.open(code+".csv") as rawfile:
        import io
        reader=csv.DictReader(io.TextIOWrapper(rawfile,encoding="utf-8-sig",newline=""))
        for line in reader:
            if line["Characteristics"]=="Percent":
                key=(line["REF_DATE"],line["VECTOR"])
                if key not in desired: continue
                r=desired[key];seen.add(key)
                assert line["COORDINATE"]==r["source_ref"].split(" · ")[1]
                if code=="13100972":
                    assert r["indicator"]==MB_INDICATORS[line["Indicators"]]
                    assert line["Age group"]=="Total, 18 years and over" and line["Sex"]=="Both sexes"
                    assert r["group"]==line["GEO"].removesuffix(", Manitoba")
                    assert r["dimension"]==("province_survey" if line["GEO"]=="Manitoba" else "region_survey")
                else:
                    assert r["indicator"]==MENTAL_INDICATORS[line["Indicators"]]
                    if code=="13100930":
                        assert r["dimension"]=="population_group" and r["group"]==line["Population group"]
                    elif r["dimension"]=="age":
                        assert r["group"]==line["Age group"] and line["GEO"]=="Canada"
                    elif r["dimension"]=="gender":
                        assert r["group"]==line["Gender"] and line["GEO"]=="Canada"
                    else:
                        assert r["group"]==line["GEO"] and r["dimension"]==("national" if line["GEO"]=="Canada" else "province")
                assert r["status"]==FLAGS[line["STATUS"]]
                val=numeric(line["VALUE"]) if line["STATUS"] in ("","E") else None
                assert numeric(r["value"])==val
            elif line["Characteristics"] in ["Low 95% confidence interval, percent","High 95% confidence interval, percent"]:
                ckey=(line["REF_DATE"],line["COORDINATE"].rsplit(".",1)[0])
                if ckey not in target_coordinates: continue
                field="ci_lower" if line["Characteristics"].startswith("Low") else "ci_upper"
                val=numeric(line["VALUE"]) if line["STATUS"] in ("","E") else None
                assert numeric(target_coordinates[ckey][field])==val
                ci[(ckey,field)]=True
    assert seen==set(desired)
    for key,r in target_coordinates.items():
        for field in ("ci_lower","ci_upper"):
            if r[field]:
                assert (key,field) in ci, (key,field)
    return len(seen)

def verify_manitoba_report(rows):
    # Independently transcribed from the report's exact printed labels (pages 95, 116–118, 126, 128, 130).
    order=["Interlake-Eastern","Northern","Prairie Mountain","Southern Health–Santé Sud","Winnipeg"]
    observed={(r["indicator"],r["dimension"],r["group"]):float(r["value"]) for r in rows}
    expected={}
    def region(name,values):
        expected.update({(name,"region_admin",g):v for g,v in zip(order,values)})
    region("Heart attack hospitalizations and deaths",[3.22,5.39,3.09,3.19,2.25])
    region("Stroke hospitalizations and deaths",[2.15,2.99,2.00,2.53,2.32])
    region("Unintentional injury hospitalizations",[786.51,938.77,831.92,601.03,655.25])
    region("Fall-related hospitalizations",[442.4,502.4,459.3,316.7,375.8])
    region("Transport-related fatalities",[8.74,11.56,10.20,7.64,3.81])
    for setting,values in [("Rural",[621,638,524,475,428]),("Urban",[465,320,264,240,209])]:
        for i,v in enumerate(values,1): expected[("Emergency department visits","income",f"{setting} quintile {i}")]=v
    expected.update({("Residents admitted to hospital at least once","income","Rural 1 (lowest)"):6.99,
                     ("Residents admitted to hospital at least once","income","Urban 5 (highest)"):3.75})
    for name,vals in [("Heart attack hospitalizations and deaths",[3.92,2.63,3.04,1.6]),
                      ("Stroke hospitalizations and deaths",[2.54,1.92,2.70,1.52])]:
        for group,v in zip(["Rural 1 (lowest)","Rural 5 (highest)","Urban 1","Urban 5"],vals):
            expected[(name,"income",group)]=v
    assert observed==expected, (set(observed.items())-set(expected.items()),set(expected.items())-set(observed.items()))
    return len(observed)

def validate_project(name,raw,data):
    target=data/name
    rows=read(target/"data.csv")
    manifest=json.loads((target/"source_manifest.json").read_text())
    for source in manifest["sources"]:
        with (raw/source["filename"]).open("rb") as f:
            assert hashlib.file_digest(f,"sha256").hexdigest()==source["sha256"]
    if name=="readmissions":
        direct=verify_cihi(raw,rows)
        detail={"CIHI workbook row and inclusion scope":direct}
    elif name=="mental-health":
        detail={code:verify_statcan(raw,code,[r for r in rows if code[:2]+"-"+code[2:4]+"-"+code[4:] in r["source_id"]]) for code in ["13100465","13100930"]}
    else:
        detail={"Statistics Canada 13-10-0972-01":verify_statcan(raw,"13100972",[r for r in rows if "Statistics Canada" in r["source_id"]]),
                "Manitoba Health report figure/label transcription":verify_manitoba_report([r for r in rows if "Manitoba Health ·" in r["source_id"]])}
    assert sum(detail.values())==len(rows)
    result={"project":name,"status":"passed","source_rows_verified":len(rows),"checks":detail,
            "note":"All normalized source observations matched independent source checks. Withheld estimates remain blank."}
    (target/"validation.json").write_text(json.dumps(result,indent=2)+"\n")
    print(name,result,flush=True)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--raw-dir",type=Path,required=True);p.add_argument("--data-dir",type=Path,required=True)
    p.add_argument("--project",choices=["all",*PROJECTS],default="all");a=p.parse_args()
    for name in PROJECTS if a.project=="all" else [a.project]:validate_project(name,a.raw_dir,a.data_dir)
