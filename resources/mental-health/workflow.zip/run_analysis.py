"""Run the project's SQL analysis against the included normalized public-data CSV."""

from pathlib import Path
import argparse
import csv
import json
import re
import sqlite3
from contextlib import closing


def run(folder):
    with (folder / "data.csv").open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        columns = reader.fieldnames
        rows = list(reader)
    numeric = {"value", "ci_lower", "ci_upper"}
    column_types = [
        f'"{column}" ' + ("REAL" if column in numeric else "TEXT") for column in columns
    ]
    placeholders = ",".join("?" for _ in columns)
    values = []
    for row in rows:
        parsed = []
        for column in columns:
            value = row[column]
            if column in numeric:
                value = float(value) if value else None
            parsed.append(value)
        values.append(parsed)

    sql = (folder / "analysis.sql").read_text(encoding="utf-8")
    parts = re.split(r"^-- result: ([a-z_0-9]+)\s*$", sql, flags=re.M)
    results = {}
    with closing(sqlite3.connect(":memory:")) as db:
        db.row_factory = sqlite3.Row
        db.execute(f"CREATE TABLE data ({','.join(column_types)})")
        db.executemany(f"INSERT INTO data VALUES ({placeholders})", values)
        for name, query in zip(parts[1::2], parts[2::2]):
            results[name] = [dict(record) for record in db.execute(query)]
            assert results[name], name
    (folder / "analysis_results.json").write_text(
        json.dumps(results, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(folder.name, f"{len(results)} SQL analyses", flush=True)
    return results


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("folder", type=Path, nargs="?", default=Path("."))
    run(p.parse_args().folder)
