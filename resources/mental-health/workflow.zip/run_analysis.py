"""Run the project's SQL analysis against the included normalized public-data CSV."""
from pathlib import Path
import argparse
import csv
import json
import re
import sqlite3

def run(folder):
    with (folder/"data.csv").open(newline="",encoding="utf-8") as stream:
        reader=csv.DictReader(stream)
        columns=reader.fieldnames
        rows=list(reader)
    con=sqlite3.connect(":memory:")
    con.row_factory=sqlite3.Row
    numeric={"value","ci_lower","ci_upper"}
    con.execute("CREATE TABLE data ("+",".join('"'+c+'" '+("REAL" if c in numeric else "TEXT") for c in columns)+")")
    con.executemany("INSERT INTO data VALUES ("+",".join("?" for _ in columns)+")",
                    [[float(r[c]) if c in numeric and r[c] else None if c in numeric else r[c] for c in columns] for r in rows])
    parts=re.split(r"^-- result: ([a-z_0-9]+)\s*$",(folder/"analysis.sql").read_text(),flags=re.M)
    results={}
    for key,sql in zip(parts[1::2],parts[2::2]):
        results[key]=[dict(r) for r in con.execute(sql)]
        assert results[key],key
    (folder/"analysis_results.json").write_text(json.dumps(results,indent=2,ensure_ascii=False)+"\n")
    con.close()
    print(folder.name, f"{len(results)} SQL analyses",flush=True)
    return results

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("folder",type=Path,nargs="?",default=Path("."))
    run(p.parse_args().folder)
