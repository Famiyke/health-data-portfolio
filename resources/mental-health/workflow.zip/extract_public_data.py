"""Extract published mental health and access-to-care estimates, confidence intervals and survey flags.

Place the source files listed in SOURCES in --raw-dir before running.
"""

import argparse
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile
import pandas as pd

SOURCES = {
    "statcan_mh_13100465.zip": "https://www150.statcan.gc.ca/n1/tbl/csv/13100465-eng.zip",
    "statcan_mh_13100930.zip": "https://www150.statcan.gc.ca/n1/tbl/csv/13100930-eng.zip",
}
FIELDS = [
    "indicator",
    "dimension",
    "period",
    "group",
    "value",
    "unit",
    "ci_lower",
    "ci_upper",
    "status",
    "source_ref",
    "source_id",
    "source_url",
    "note",
]

PROVINCES = {
    "Canada",
    "Newfoundland and Labrador",
    "Prince Edward Island",
    "Nova Scotia",
    "New Brunswick",
    "Quebec",
    "Ontario",
    "Manitoba",
    "Saskatchewan",
    "Alberta",
    "British Columbia",
}

MENTAL_INDICATORS = {
    "Perceived mental health, very good or excellent": "Very good or excellent perceived mental health",
    "Perceived mental health, fair or poor": "Fair or poor perceived mental health",
    "Perceived mental health, good": "Good perceived mental health",
    "Perceived need for mental health care, no need": "No perceived mental health care need",
    "Perceived need for mental health care, all needs met": "Mental health care needs fully met",
    "Perceived need for mental health care, need not met": "Mental health care needs not met",
    "Perceived need for mental health care, needs partially met": "Mental health care needs partially met",
    "Mental health services, professional consultation/service used, 12 months": "Mental health consultation or service use, past 12 months",
    "Major depressive episode, 12 months": "Major depressive episode, past 12 months",
    "Generalized anxiety disorder, 12 months": "Generalized anxiety disorder, past 12 months",
}

FLAGS = {
    "": "Published",
    "E": "Use with caution",
    "F": "Too unreliable to publish",
    "x": "Suppressed",
    "..": "Not available",
}
SOURCE_TABLE = {
    "13100465": "Statistics Canada Table 13-10-0465-01",
    "13100930": "Statistics Canada Table 13-10-0930-01",
}
SOURCE_FILE = {"13100465": "statcan_mh_13100465.zip", "13100930": "statcan_mh_13100930.zip"}


def numeric(value):
    try:
        return float(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return None


def row(
    indicator,
    dimension,
    period,
    group,
    value,
    unit,
    lower,
    upper,
    status,
    source_ref,
    source_id,
    source_url,
    note="",
):
    assert status != "Published" or value is not None
    return {
        "indicator": indicator,
        "dimension": dimension,
        "period": period,
        "group": group,
        "value": value,
        "unit": unit,
        "ci_lower": lower,
        "ci_upper": upper,
        "status": status,
        "source_ref": source_ref,
        "source_id": source_id,
        "source_url": source_url,
        "note": note,
    }


def statcan_extract(raw: Path, code, indicators, selector, dimension, labels, notes):
    """Join each estimate with published confidence intervals and source vector."""
    cols = [
        "REF_DATE",
        "GEO",
        "Age group",
        "Indicators",
        "Characteristics",
        "VALUE",
        "STATUS",
        "VECTOR",
        "COORDINATE",
    ]
    cols += ["Gender"]
    if code == "13100930":
        cols += ["Population group"]
    stats = [
        "Percent",
        "Low 95% confidence interval, percent",
        "High 95% confidence interval, percent",
    ]
    pieces = []
    with ZipFile(raw / SOURCE_FILE[code]) as zipped:
        for d in pd.read_csv(
            zipped.open(code + ".csv"),
            usecols=cols,
            dtype=str,
            keep_default_na=False,
            chunksize=100_000,
        ):
            d = d[d["Indicators"].isin(indicators) & d["Characteristics"].isin(stats)]
            if len(d):
                pieces.append(d.loc[selector(d)])
    data = pd.concat(pieces, ignore_index=True)
    key = [
        c
        for c in ["REF_DATE", "GEO", "Age group", "Sex", "Gender", "Population group", "Indicators"]
        if c in data
    ]
    assert not data.duplicated(key + ["Characteristics"]).any()
    by_key = data.set_index(key + ["Characteristics"])
    result = []
    for _, estimate in data[data.Characteristics == "Percent"].iterrows():
        k = tuple(estimate[c] for c in key)

        def confidence(stat):
            try:
                cv = by_key.loc[k + (stat,)]
                return numeric(cv.VALUE) if cv.STATUS in ("", "E") else None
            except KeyError:
                return None

        val = numeric(estimate.VALUE) if estimate.STATUS in ("", "E") else None
        result.append(
            row(
                indicators[estimate.Indicators],
                dimension(estimate),
                estimate.REF_DATE,
                labels(estimate),
                val,
                "percent",
                confidence(stats[1]),
                confidence(stats[2]),
                FLAGS.get(estimate.STATUS, "Not available"),
                estimate.VECTOR + " · " + estimate.COORDINATE,
                SOURCE_TABLE[code],
                "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=" + code + "01",
                notes(estimate),
            )
        )
    return result


def mental_health(raw: Path):
    total_age = "Total, 15 years and over"
    both = "Total, gender of person"
    age_groups = {"15 to 24 years", "25 to 44 years", "45 to 64 years", "65 years and over"}

    def selector(d):
        national_total = d.GEO.eq("Canada") & d["Age group"].eq(total_age) & d.Gender.eq(both)
        extra = d.Indicators.isin(
            [
                "Perceived mental health, good",
                "Perceived need for mental health care, no need",
                "Perceived need for mental health care, all needs met",
            ]
        )
        return (
            d.REF_DATE.isin(["2012", "2022"])
            & (~extra | national_total)
            & (
                (d.GEO.isin(PROVINCES) & d["Age group"].eq(total_age) & d.Gender.eq(both))
                | (d.GEO.eq("Canada") & d["Age group"].isin(age_groups) & d.Gender.eq(both))
                | (
                    d.GEO.eq("Canada")
                    & d["Age group"].eq(total_age)
                    & d.Gender.isin(["Men+", "Women+"])
                    & d.REF_DATE.eq("2022")
                )
            )
        )

    def dimension(r):
        if r["Age group"] != total_age:
            return "age"
        if r.Gender != both:
            return "gender"
        return "national" if r.GEO == "Canada" else "province"

    def label(r):
        return (
            r["Age group"]
            if r["Age group"] != total_age
            else r.Gender if r.Gender != both else r.GEO
        )

    out = statcan_extract(
        raw,
        "13100465",
        MENTAL_INDICATORS,
        selector,
        dimension,
        label,
        lambda r: "Age, geography and gender as published; weighted survey estimate, ages 15+.",
    )
    chosen = {
        k: v
        for k, v in MENTAL_INDICATORS.items()
        if k
        in {
            "Perceived mental health, fair or poor",
            "Perceived mental health, very good or excellent",
            "Perceived need for mental health care, need not met",
        }
    }
    out += statcan_extract(
        raw,
        "13100930",
        chosen,
        lambda d: d.REF_DATE.eq("2022")
        & d.GEO.eq("Canada")
        & d["Age group"].eq(total_age)
        & d.Gender.eq(both),
        lambda r: "population_group",
        lambda r: r["Population group"],
        lambda r: "Published population group estimate; source exclusions and quality flags apply.",
    )
    return sorted(out, key=lambda r: (r["indicator"], r["dimension"], r["period"], r["group"]))


PROJECT_NAME = "mental-health"


def source_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_project(name, raw, output):
    files = list(SOURCES)
    target = output / name
    target.mkdir(parents=True, exist_ok=True)
    records = mental_health(raw)
    assert records
    keys = [(r["indicator"], r["dimension"], r["period"], r["group"]) for r in records]
    assert len(keys) == len(set(keys)), "Duplicate observation"
    for r in records:
        val = r["value"]
        if val is not None:
            assert val >= 0 and (r["unit"] != "percent" or val <= 100)
            if r["ci_lower"] is not None and r["ci_upper"] is not None:
                assert r["ci_lower"] - 0.06 <= val <= r["ci_upper"] + 0.06, r
        elif r["status"] in ("Published", "Use with caution"):
            raise ValueError(r)
    with (target / "data.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)
    manifest = {
        "project": name,
        "sources": [
            {
                "filename": f,
                "url": SOURCES[f],
                "size_bytes": (raw / f).stat().st_size,
                "sha256": source_hash(raw / f),
            }
            for f in files
        ],
        "observations": len(records),
        "published_numeric": sum(r["value"] is not None for r in records),
        "quality_caution": sum(r["status"] == "Use with caution" for r in records),
        "unavailable_or_suppressed": sum(r["value"] is None for r in records),
    }
    (target / "source_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(
        name,
        manifest["observations"],
        "rows;",
        manifest["published_numeric"],
        "numeric;",
        manifest["unavailable_or_suppressed"],
        "withheld",
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--project", choices=["all", PROJECT_NAME], default="all")
    args = parser.parse_args()
    write_project(PROJECT_NAME, args.raw_dir, args.output_dir)
