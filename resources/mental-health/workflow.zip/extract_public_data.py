"""Extract documented public aggregates for three healthcare case studies.

Run with Python 3.11+, pandas, lxml, openpyxl and Poppler's pdftotext.
Download the source files named in SOURCES into --raw-dir first.
The script retains source keys and publication/suppression status; it never imputes values.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import subprocess
from pathlib import Path
from zipfile import ZipFile

import pandas as pd
from lxml import etree
from openpyxl.utils.datetime import from_excel

SOURCES = {
    "cihi_indicators.xlsx": "https://www.cihi.ca/sites/default/files/document/indicator-library-indicator-data-no-breakdowns-en.xlsx",
    "statcan_mh_13100465.zip": "https://www150.statcan.gc.ca/n1/tbl/csv/13100465-eng.zip",
    "statcan_mh_13100930.zip": "https://www150.statcan.gc.ca/n1/tbl/csv/13100930-eng.zip",
    "statcan_health_13100972.zip": "https://www150.statcan.gc.ca/n1/tbl/csv/13100972-eng.zip",
    "mb_health_status2025.pdf": "https://www.gov.mb.ca/asset_library/en/cppho/docs/health-status-2025.pdf",
}
FIELDS = ["indicator", "dimension", "period", "group", "value", "unit",
          "ci_lower", "ci_upper", "status", "source_ref", "source_id", "source_url", "note"]
GROUPS = {"All Patients Readmitted to Hospital": "Overall",
          "Medical Patients Readmitted to Hospital": "Medical",
          "Surgical Patients Readmitted to Hospital": "Surgical",
          "Pediatric Patients Readmitted to Hospital": "Pediatric",
          "Obstetric Patients Readmitted to Hospital": "Obstetric"}
PROVINCES = {"Canada", "Newfoundland and Labrador", "Prince Edward Island", "Nova Scotia",
             "New Brunswick", "Quebec", "Ontario", "Manitoba", "Saskatchewan", "Alberta",
             "British Columbia"}
MENTAL_INDICATORS = {
    "Perceived mental health, very good or excellent": "Very good or excellent perceived mental health",
    "Perceived mental health, fair or poor": "Fair or poor perceived mental health",
    "Perceived mental health, good": "Good perceived mental health",
    "Perceived need for mental health care, no need": "No perceived mental health care need",
    "Perceived need for mental health care, all needs met": "Mental health care needs fully met",
    "Perceived need for mental health care, need not met": "Mental health care needs not met",
    "Perceived need for mental health care, needs partially met": "Mental health care needs partially met",
    "Mental health services, professional consultation/service used, 12 months": "Mental health consultation or service use, past 12 months",
    "Major depressive episode, 12 months": "Major depressive episode, past 12 months",
    "Generalized anxiety disorder, 12 months": "Generalized anxiety disorder, past 12 months",
}
MB_INDICATORS = {"Diabetes": "Self-reported diabetes",
                 "High blood pressure": "Self-reported high blood pressure",
                 "Current smoker, daily or occasional": "Current smoking, daily or occasional",
                 "Perceived health, fair or poor": "Fair or poor perceived health",
                 "Perceived mental health, fair or poor": "Fair or poor perceived mental health",
                 "Mood disorder": "Self-reported mood disorder",
                 "Anxiety disorder": "Self-reported anxiety disorder"}
MB_REGIONS = {"IERHA": "Interlake-Eastern", "NHR": "Northern", "Northern": "Northern",
              "PMH": "Prairie Mountain", "SH-SS": "Southern Health–Santé Sud", "WRHA": "Winnipeg",
              "MB": "Manitoba"}
FLAGS = {"": "Published", "E": "Use with caution", "F": "Too unreliable to publish",
         "x": "Suppressed", "..": "Not available"}
SOURCE_TABLE = {
    "13100465": "Statistics Canada Table 13-10-0465-01",
    "13100930": "Statistics Canada Table 13-10-0930-01",
    "13100972": "Statistics Canada Table 13-10-0972-01",
}
SOURCE_FILE = {
    "13100465": "statcan_mh_13100465.zip",
    "13100930": "statcan_mh_13100930.zip",
    "13100972": "statcan_health_13100972.zip",
}

def numeric(value):
    try:
        return float(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return None

def row(indicator, dimension, period, group, value, unit, lower, upper, status, source_ref, source_id, source_url, note=""):
    assert status != "Published" or value is not None
    return dict(zip(FIELDS, (indicator, dimension, period, group, value, unit, lower, upper,
                             status, source_ref, source_id, source_url, note)))

def readmissions(raw: Path):
    """Scan XLSX shared strings and rows without holding the 491k-row workbook in memory."""
    namespace = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    def cell_value(c, shared):
        v = c.find(namespace + "v")
        return "" if v is None else shared[int(v.text)] if c.get("t") == "s" else v.text
    output = []
    with ZipFile(raw / "cihi_indicators.xlsx") as archive:
        shared = ["".join(si.itertext()) for si in etree.fromstring(archive.read("xl/sharedStrings.xml"))]
        indicator_ids = {str(i): s for i, s in enumerate(shared) if s in GROUPS}
        with archive.open("xl/worksheets/sheet1.xml") as sheet:
            for _, item in etree.iterparse(sheet, events=("end",), tag=namespace + "row"):
                r = item.get("r")
                name_element = item.find(f"{namespace}c[@r='F{r}']/{namespace}v")
                if name_element is not None and name_element.text in indicator_ids:
                    fields = {re.sub(r"\d+", "", c.get("r")): cell_value(c, shared) for c in item}
                    if fields.get("L") == "Risk-adjusted rate" and fields.get("M") == "Yes" and fields.get("J") == "Not applicable":
                        level = fields.get("E")
                        province = fields.get("B")
                        group = GROUPS[fields["F"]]
                        eligible = level in {"National", "Province/territory"}
                        eligible |= (group == "Overall" and province == "Manitoba" and level == "Health region")
                        eligible |= (group == "Overall" and province == "Manitoba" and level == "Facility"
                                     and any(k in fields.get("W", "") for k in ("Teaching", "Medium", "Large")))
                        if eligible:
                            raw_value = fields.get("N", "")
                            val = numeric(raw_value)
                            status = "Published" if val is not None else raw_value or "Not available"
                            note = fields.get("Y", "")
                            if fields.get("W") not in ("", "-", None):
                                note = "; ".join(filter(None, [note, fields["W"].replace(" ¿ ", " · ")]))
                            if fields.get("T") not in ("", "-", "Suppressed", None):
                                note = "; ".join(filter(None, [note, fields["T"]]))
                            if fields.get("AA") not in ("", "-", None):
                                note = "; ".join(filter(None, [note, "CIHI trend note: " + fields["AA"]]))
                            refresh = fields.get("AB")
                            if refresh and numeric(refresh) is not None:
                                refresh = from_excel(float(refresh)).date().isoformat()
                            note = "; ".join(filter(None, [note, "Workbook refresh " + str(refresh)]))
                            dimension = {"National":"national", "Province/territory":"province",
                                         "Health region":"mb_region", "Facility":"mb_facility"}[level]
                            output.append(row(group, dimension, fields["I"],
                                              fields["A"].replace(" (Man.)", ""), val, "per 100 episodes",
                                              numeric(fields.get("P")), numeric(fields.get("Q")), status,
                                              "Sheet1 row " + r, "CIHI Indicator Library · no breakdowns",
                                              SOURCES["cihi_indicators.xlsx"], note))
                item.clear()
                while item.getprevious() is not None:
                    del item.getparent()[0]
    return sorted(output, key=lambda r:(r["dimension"], r["indicator"], r["period"], r["group"]))

def statcan_extract(raw: Path, code, indicators, selector, dimension, labels, notes):
    """Join each estimate with published confidence intervals and source vector."""
    cols = ["REF_DATE","GEO","Age group","Indicators","Characteristics","VALUE","STATUS","VECTOR","COORDINATE"]
    cols += ["Sex"] if code == "13100972" else ["Gender"]
    if code == "13100930":
        cols += ["Population group"]
    stats = ["Percent", "Low 95% confidence interval, percent", "High 95% confidence interval, percent"]
    pieces = []
    with ZipFile(raw / SOURCE_FILE[code]) as zipped:
        for d in pd.read_csv(zipped.open(code + ".csv"), usecols=cols, dtype=str, keep_default_na=False, chunksize=100_000):
            d = d[d["Indicators"].isin(indicators) & d["Characteristics"].isin(stats)]
            if len(d):
                pieces.append(d.loc[selector(d)])
    data = pd.concat(pieces, ignore_index=True)
    key = [c for c in ["REF_DATE", "GEO", "Age group", "Sex", "Gender", "Population group", "Indicators"] if c in data]
    assert not data.duplicated(key + ["Characteristics"]).any()
    by_key = data.set_index(key + ["Characteristics"])
    result = []
    for _, estimate in data[data.Characteristics == "Percent"].iterrows():
        k = tuple(estimate[c] for c in key)
        def confidence(stat):
            try:
                cv = by_key.loc[k + (stat,)]
                return numeric(cv.VALUE) if cv.STATUS in ("", "E") else None
            except KeyError:
                return None
        val = numeric(estimate.VALUE) if estimate.STATUS in ("", "E") else None
        result.append(row(indicators[estimate.Indicators], dimension(estimate), estimate.REF_DATE,
                          labels(estimate), val, "percent", confidence(stats[1]), confidence(stats[2]),
                          FLAGS.get(estimate.STATUS, "Not available"), estimate.VECTOR + " · " + estimate.COORDINATE,
                          SOURCE_TABLE[code], "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=" + code + "01",
                          notes(estimate)))
    return result

def mental_health(raw: Path):
    total_age = "Total, 15 years and over"
    both = "Total, gender of person"
    age_groups = {"15 to 24 years","25 to 44 years","45 to 64 years","65 years and over"}
    def selector(d):
        national_total = d.GEO.eq("Canada") & d["Age group"].eq(total_age) & d.Gender.eq(both)
        extra = d.Indicators.isin(["Perceived mental health, good",
                                   "Perceived need for mental health care, no need",
                                   "Perceived need for mental health care, all needs met"])
        return d.REF_DATE.isin(["2012","2022"]) & (~extra | national_total) & (
            (d.GEO.isin(PROVINCES) & d["Age group"].eq(total_age) & d.Gender.eq(both))
            | (d.GEO.eq("Canada") & d["Age group"].isin(age_groups) & d.Gender.eq(both))
            | (d.GEO.eq("Canada") & d["Age group"].eq(total_age) & d.Gender.isin(["Men+","Women+"]) & d.REF_DATE.eq("2022")))
    def dimension(r):
        if r["Age group"] != total_age: return "age"
        if r.Gender != both: return "gender"
        return "national" if r.GEO == "Canada" else "province"
    def label(r):
        return r["Age group"] if r["Age group"] != total_age else r.Gender if r.Gender != both else r.GEO
    out = statcan_extract(raw, "13100465", MENTAL_INDICATORS, selector, dimension, label,
                          lambda r: "Age, geography and gender as published; weighted survey estimate, ages 15+.")
    chosen = {k:v for k,v in MENTAL_INDICATORS.items() if k in
              {"Perceived mental health, fair or poor", "Perceived mental health, very good or excellent",
               "Perceived need for mental health care, need not met"}}
    out += statcan_extract(raw, "13100930", chosen,
                           lambda d: d.REF_DATE.eq("2022") & d.GEO.eq("Canada") & d["Age group"].eq(total_age) & d.Gender.eq(both),
                           lambda r:"population_group",lambda r:r["Population group"],
                           lambda r:"Published population group estimate; source exclusions and quality flags apply.")
    return sorted(out, key=lambda r:(r["indicator"], r["dimension"], r["period"], r["group"]))

def extract_mb_report(raw: Path):
    """Extract only explicitly printed values from identified pages of the 2025 official report."""
    pages = subprocess.check_output(["pdftotext","-layout",str(raw/"mb_health_status2025.pdf"),"-"], text=True).split("\f")
    output = []
    source_url = SOURCES["mb_health_status2025.pdf"]
    source_base = "Manitoba Health · A Healthier Manitoba For All (2025), "
    def emit(indicator, dimension, period, group, value, unit, page, note):
        output.append(row(indicator, dimension, period, group, float(value), unit, None, None, "Published",
                          f"Printed p. {page-4} (PDF p. {page})", source_base + f"p. {page-4}", source_url+"#page="+str(page), note))
    region_metrics = [
        (120, "Heart attack hospitalizations and deaths", "2018–2022", "per 1,000 residents aged 40+", "MCHP 2024 RHA Indicators Atlas, reported by Manitoba Health.", "RATES OF HEART ATTACK"),
        (122, "Stroke hospitalizations and deaths", "2018–2022", "per 1,000 residents aged 40+", "MCHP 2024 RHA Indicators Atlas, reported by Manitoba Health.", "REGIONAL R ATES OF STROKE"),
        (130, "Unintentional injury hospitalizations", "2023–2024", "per 100,000 residents", "Manitoba Health administrative report.", "2023-24 HOSPITALIZ ATION R ATE"),
        (132, "Fall-related hospitalizations", "2023–2024", "per 100,000 residents", "Manitoba Health administrative report.", "REGIONAL R ATES OF FALL-REL ATED"),
        (134, "Transport-related fatalities", "2022–2023", "per 100,000 residents", "Manitoba Health administrative report.", "NUMBER OF TR ANSPORT-REL ATED"),
    ]
    pattern = re.compile(r"\b(IERHA|NHR|Nor\s*thern|PMH|SH-SS|WRHA)(?:\s+3)?\s{2,}(\d+(?:\.\d+)?)")
    for page, name, period, unit, note, anchor in region_metrics:
        src = pages[page-1]
        assert anchor in src
        matches = pattern.findall(src)
        values = {}
        for key, val in matches:
            key = "Northern" if "".join(key.split()).lower() == "northern" else key
            assert key in MB_REGIONS
            values[MB_REGIONS[key]] = float(val)
        assert len(values) == 5, (page, values)
        for group, val in values.items():
            emit(name,"region_admin",period,group,val,unit,page,note)
    page=99
    src=pages[page-1]
    # ED figure labels R1/R5 and U1/U5 may share a row with textual callouts.
    matches = re.findall(r"\b([RU][1-5])\s+(\d+)\s*$", src, re.M)
    # The figure's two lowest quintile labels wrap below their values; inspect exact lines separately.
    matches += re.findall(r"\b([RU]1)\s*\n\s*\(lowest (?:rural|urban)\)\s+(\d+)", src)
    # The labels sit on vertically separate lines; enforce all ten printed groups.
    vals = dict(matches)
    for code in ["R1", "U1"]:
        if code not in vals:
            m = re.search(r"\b"+code+r"\s*\n\s*\(lowest (?:rural|urban)\)\s+(\d+)",src)
            if m: vals[code]=m.group(1)
    assert len(vals)==10, vals
    for code,val in sorted(vals.items()):
        label = ("Rural" if code[0]=="R" else "Urban") + " quintile " + code[1]
        emit("Emergency department visits", "income", "2023", label, val,"visits per 1,000 people",page,"Shared Health Manitoba, reported by Manitoba Health. Q1 = lowest income, Q5 = highest.")
    hosp = re.findall(r"(Rural 1 \(lowest\)|Urban 5 \(highest\))\s+(\d+\.\d+)", src)
    assert len(hosp) == 2
    for label,val in hosp:
        emit("Residents admitted to hospital at least once","income","2022–2023",label,val,"age- and sex-adjusted percent",page,"Source reports selected income settings, not all ten combinations.")
    for page,name in [(121,"Heart attack hospitalizations and deaths"),(122,"Stroke hospitalizations and deaths")]:
        src=pages[page-1]
        vals=re.findall(r"(Rural [15] \((?:highest|lowest)\)|Urban [15])\s+[–-]\s+(\d+(?:\.\d+)?)",src)
        assert len(vals)==4, (page,vals)
        for label,val in vals:
            # The PDF text layer attaches superscript reference 40 to the final 2.70 value.
            # The report's printed value is 2.70, not 2.7040 (confirmed from separate font span).
            if page == 122 and label == "Urban 1":
                assert val in {"2.70", "2.7040"}
                val = "2.70"
            emit(name,"income","2018–2022",label,val,"per 1,000 residents aged 40+",page,"MCHP 2024 RHA Indicators Atlas online supplement; Q1 lowest, Q5 highest. Selected income extremes.")
    return output

def manitoba(raw: Path):
    def label(r):
        return r.GEO.removesuffix(", Manitoba")
    out = statcan_extract(raw,"13100972",MB_INDICATORS,
                          lambda d:(d.GEO.eq("Manitoba")|d.GEO.str.endswith(", Manitoba")) & d["Age group"].eq("Total, 18 years and over") & d.Sex.eq("Both sexes"),
                          lambda r:"province_survey" if r.GEO=="Manitoba" else "region_survey",label,
                          lambda r:"CCHS two-year weighted survey estimate; self-reported, adults 18+; both sexes.")
    out += extract_mb_report(raw)
    return sorted(out, key=lambda r:(r["indicator"], r["dimension"], r["period"], r["group"]))

PROJECTS = {"readmissions": (readmissions, ["cihi_indicators.xlsx"]),
            "mental-health": (mental_health, ["statcan_mh_13100465.zip","statcan_mh_13100930.zip"]),
            "manitoba": (manitoba, ["statcan_health_13100972.zip","mb_health_status2025.pdf"])}

def write_project(name, raw, output):
    transform, files = PROJECTS[name]
    target = output / name
    target.mkdir(parents=True, exist_ok=True)
    records = transform(raw)
    assert records
    keys = [(r["indicator"],r["dimension"],r["period"],r["group"]) for r in records]
    assert len(keys)==len(set(keys)), "Duplicate observation"
    for r in records:
        val = r["value"]
        if val is not None:
            assert val>=0 and (r["unit"]!="percent" or val<=100)
            if r["ci_lower"] is not None and r["ci_upper"] is not None:
                assert r["ci_lower"]-.06<=val<=r["ci_upper"]+.06, r
        elif r["status"] in ("Published","Use with caution"):
            raise ValueError(r)
    with (target/"data.csv").open("w",newline="",encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)
    manifest={"project":name,"sources":[{"filename":f,"url":SOURCES[f],"size_bytes":(raw/f).stat().st_size,
                                         "sha256":hashlib.file_digest((raw/f).open("rb"),"sha256").hexdigest()} for f in files],
              "observations":len(records),"published_numeric":sum(r["value"] is not None for r in records),
              "quality_caution":sum(r["status"]=="Use with caution" for r in records),
              "unavailable_or_suppressed":sum(r["value"] is None for r in records)}
    (target/"source_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(name, manifest["observations"],"rows;",manifest["published_numeric"],"numeric;",manifest["unavailable_or_suppressed"],"withheld",flush=True)

if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir",type=Path,required=True)
    parser.add_argument("--output-dir",type=Path,required=True)
    parser.add_argument("--project",choices=["all",*PROJECTS],default="all")
    args=parser.parse_args()
    for name in PROJECTS if args.project=="all" else [args.project]:
        write_project(name,args.raw_dir,args.output_dir)
