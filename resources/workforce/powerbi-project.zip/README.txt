CANADIAN WORKFORCE ANALYTICS · POWER BI PROJECT

Extract this ZIP to a directory, then open Workforce.pbip in a recent Power BI Desktop release with Power BI project/PBIR enabled. The embedded source rows use Power Query #table, so no external CSV path or credentials are needed. If prompted, refresh once. Each page uses a reporting-period slicer and shows the latest selected period by category. The DAX measure uses SELECTEDVALUE to prevent summing rates or wages. Source references and flags are included in each table. The original source extracts and SQL are in the separate workflow package.

These are editable project files, not a PBIX binary. The source structure and field bindings were checked; native Desktop execution was not available in this environment. The verified web dashboards are also available on the portfolio.
