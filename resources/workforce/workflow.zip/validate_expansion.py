"""Reconcile each extracted observation to the original published file."""

import argparse
import csv
import io
import hashlib
import json
import zipfile
import math
from pathlib import Path
from collections import defaultdict
import openpyxl


def read(path):
    with path.open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def close(a, b):
    return math.isclose(float(a), float(b), rel_tol=1e-10, abs_tol=1e-8)


def validate(name, raw, folder):
    rows = read(folder / "data.csv")
    sources = defaultdict(list)
    for r in rows:
        sources[r["source_file"]].append(r)
    manifest = json.loads((folder / "source_manifest.json").read_text())
    for m in manifest["sources"]:
        assert hashlib.sha256((raw / m["file"]).read_bytes()).hexdigest() == m["sha256"]
    count = 0
    for filename, records in sources.items():
        if filename.endswith(".zip"):
            key = lambda r: (r["VECTOR"], r["COORDINATE"], r["REF_DATE"])
            wanted = {tuple(r["source_reference"].split(" · ")): r for r in records}
            assert len(wanted) == len(records)
            with zipfile.ZipFile(raw / filename) as z:
                f = next(n for n in z.namelist() if n.endswith(".csv") and "MetaData" not in n)
                with z.open(f) as stream:
                    for source in csv.DictReader(io.TextIOWrapper(stream, encoding="utf-8-sig")):
                        k = key(source)
                        if k not in wanted:
                            continue
                        r = wanted.pop(k)
                        assert (
                            r["raw_value"] == source["VALUE"]
                            and r["raw_flag"] == source["STATUS"]
                            and r["geography"] == source["GEO"]
                        )
                        assert (not r["value"] and not source["VALUE"]) or close(
                            r["value"], source["VALUE"]
                        )
                        q = f"{source['REF_DATE'][:4]} Q{(int(source['REF_DATE'][5:7])-1)//3+1}"
                        assert r["period"] == q and source["SCALAR_FACTOR"] == "units"
                        count += 1
            assert not wanted, len(wanted)
        else:
            w = openpyxl.load_workbook(raw / filename, read_only=False, data_only=True)
            for r in records:
                sheet, cell = r["source_reference"].split("!")
                val = w[sheet][cell].value
                assert str(val if val is not None else "") == r["raw_value"], (r, val)
                try:
                    number = float(str(val).rstrip("*"))
                except ValueError:
                    number = None
                if number is None:
                    assert r["value"] == ""
                else:
                    assert close(
                        r["value"], number * (100 if r["metric"] == "Overtime rate" else 1)
                    )
                if filename == "cihi-quickstats.xlsx":
                    i = w[sheet][cell].row
                    assert (r["geography"], r["period"], r["dimension"]) == tuple(
                        w[sheet].cell(i, c).value for c in (2, 3, 4)
                    )
                else:
                    i = w[sheet][cell].row
                    assert str(w[sheet].cell(i, 2).value) == r["period"]
                    assert (
                        " ".join(w[sheet].cell(2, 4).value.split(":")[0].split()) == r["geography"]
                    )
                count += 1
            w.close()
    assert count == len(rows)
    val = json.loads((folder / "validation.json").read_text())
    val["independently_matched_source_records"] = count
    val["status"] = "passed"
    (folder / "validation.json").write_text(json.dumps(val, indent=2) + "\n")
    print(name, "PASS", count, "independent source matches")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--project", choices=["workforce", "all"], default="workforce")
    args = parser.parse_args()
    validate("workforce", args.raw_dir, args.output_dir / "workforce")


if __name__ == "__main__":
    main()
