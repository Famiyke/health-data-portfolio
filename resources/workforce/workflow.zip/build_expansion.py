"""Build the labour market, hospital staffing and professional supply analysis.

Use --download to obtain the original public files. The source manifest retains their hashes.
"""

import argparse
import csv
import io
import json
import zipfile
import hashlib
from pathlib import Path
from urllib.request import Request, urlopen
from run_analysis import run as run_sql
import openpyxl

RETRIEVED = "2026-11-22"

IND = "North American Industry Classification System (NAICS)"

GEO = [
    "Canada",
    "Newfoundland and Labrador",
    "Prince Edward Island",
    "Nova Scotia",
    "New Brunswick",
    "Quebec",
    "Ontario",
    "Manitoba",
    "Saskatchewan",
    "Alberta",
    "British Columbia",
    "Yukon",
    "Northwest Territories",
    "Nunavut",
]

SOURCES = {
    "workforce-statcan.zip": (
        "Statistics Canada 14-10-0442-01",
        "https://www150.statcan.gc.ca/n1/tbl/csv/14100442-eng.zip",
        "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1410044201",
    ),
    "cihi-quickstats.xlsx": (
        "CIHI Health Workforce Quick Stats 2024",
        "https://www.cihi.ca/sites/default/files/document/health-workforce-quickstats-2024-data-tables-en.xlsx",
        "https://www.cihi.ca/en/the-state-of-the-health-workforce-in-canada-2024/go-in-depth-2024-health-workforce-data",
    ),
    "cihi-overview.xlsx": (
        "CIHI Health Workforce Overview 2020–2024",
        "https://www.cihi.ca/sites/default/files/document/data-file/health-workforce-canada-2020-2024-overview-data-tables-en.xlsx",
        "https://www.cihi.ca/en/health-workforce-in-canada-overview",
    ),
}

SECTORS = {
    "Total, all industries": "All industries",
    "Health care and social assistance [62]": "Health care and social assistance",
    "Retail trade [44-45]": "Retail trade",
    "Manufacturing [31-33]": "Manufacturing",
    "Construction [23]": "Construction",
    "Accommodation and food services [72]": "Accommodation and food services",
    "Professional, scientific and technical services [54]": "Professional, scientific and technical services",
    "Finance and insurance [52]": "Finance and insurance",
}

STATS = {
    "Job vacancies": "Job vacancies",
    "Payroll employees": "Payroll employees",
    "Job vacancy rate": "Job vacancy rate",
    "Average offered hourly wage": "Offered hourly wage",
}

PROFESSIONS = [
    "Registered nurses",
    "Licensed practical nurses",
    "Nurse practitioners",
    "Physicians",
    "Medical laboratory technologists",
    "Paramedics",
]

AGG = "Provinces/territories with available data"

FIELDS = [
    "source_id",
    "source_file",
    "period",
    "geography",
    "dimension",
    "metric",
    "value",
    "unit",
    "status",
    "raw_value",
    "raw_flag",
    "source_reference",
    "source_url",
]

FLAGS = {
    "A": "Published · excellent",
    "B": "Published · very good",
    "C": "Published · good",
    "D": "Published · acceptable",
    "E": "Use with caution",
    "F": "Too unreliable to publish",
    "x": "Suppressed",
    "..": "Unavailable",
    "...": "Not applicable",
    "": "Published",
}


def quarter(s):
    return f"{s[:4]} Q{(int(s[5:7])-1)//3+1}"


def as_num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def stat_rows(raw, file):
    with zipfile.ZipFile(raw / file) as z:
        n = next(n for n in z.namelist() if n.endswith(".csv") and "MetaData" not in n)
        with z.open(n) as f:
            yield from csv.DictReader(io.TextIOWrapper(f, encoding="utf-8-sig"))


def record(file, period, geo, dim, metric, value, unit, status, raw_val, flag, reference):
    source, _, url = SOURCES[file]
    return {
        "source_id": source,
        "source_file": file,
        "period": period,
        "geography": geo,
        "dimension": dim,
        "metric": metric,
        "value": value,
        "unit": unit,
        "status": status,
        "raw_value": "" if raw_val is None else str(raw_val),
        "raw_flag": str(flag or ""),
        "source_reference": reference,
        "source_url": url,
    }


def stat_record(file, r, period, dim, metric, unit, divisor=1):
    val = as_num(r["VALUE"])
    flag = r["STATUS"]
    status = FLAGS.get(flag, flag or "Published")
    if val is None:
        status = FLAGS.get(flag, "Unavailable") if flag else "Unavailable"
    return record(
        file,
        period,
        r["GEO"],
        dim,
        metric,
        None if val is None else val / divisor,
        unit,
        status,
        r["VALUE"],
        flag,
        f"{r['VECTOR']} · {r['COORDINATE']} · {r['REF_DATE']}",
    )


def cihi_record(file, sheet, row, col, period, geo, dim, metric, raw_val, unit, mult=1):
    # Preserve asterisks and suppressed/not-reported symbols from CIHI.
    flag = "*" if isinstance(raw_val, str) and raw_val.endswith("*") else ""
    val = as_num(raw_val.rstrip("*") if isinstance(raw_val, str) else raw_val)
    status = "Use with caution" if flag else "Published"
    if val is None:
        flag = str(raw_val or "—")
        status = {"x": "Suppressed", "n/r": "Not reported"}.get(flag, "Unavailable")
    return record(
        file,
        period,
        geo,
        dim,
        metric,
        None if val is None else val * mult,
        unit,
        status,
        raw_val,
        flag,
        f"{sheet}!{openpyxl.utils.get_column_letter(col)}{row}",
    )


def write_csv(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def source_manifest(raw, files):
    return {
        "source_retrieval_date": RETRIEVED,
        "sources": [
            {
                "file": p,
                "publisher": SOURCES[p][0],
                "download_url": SOURCES[p][1],
                "reference_url": SOURCES[p][2],
                "sha256": hashlib.sha256((raw / p).read_bytes()).hexdigest(),
                "bytes": (raw / p).stat().st_size,
            }
            for p in files
        ],
    }


def dashrow(row, period, label=None, value=None, status=None, reference=None, note=None):
    return {
        "year": period,
        "label": label or row["geography"],
        "value": row["value"] if value is None else value,
        "unit": row["unit"],
        "status": status or row["status"],
        "sourceId": row["source_id"],
        "sourceRef": reference or row["source_reference"],
        "sourceUrl": row["source_url"],
        "n": reference or row["source_reference"],
        **({"note": note} if note else {}),
    }


def view(name, section, rows, explain, chart="bar", digits=1, default=None):
    assert rows and all(r["status"] and r["sourceRef"] for r in rows)
    years = list(dict.fromkeys(r["year"] for r in rows))
    return {
        "name": name,
        "section": section,
        "chart": chart,
        "digits": digits,
        "years": years,
        "defaultYear": default or years[-1],
        "rows": rows,
        "explain": explain,
        "denominatorLabel": "Source reference",
    }


def lookup(rows):
    d = {}
    for r in rows:
        key = tuple(r[k] for k in ("source_id", "period", "geography", "dimension", "metric"))
        assert key not in d, key
        d[key] = r
    return d


def load_workforce_records(raw):
    files = ["workforce-statcan.zip", "cihi-quickstats.xlsx", "cihi-overview.xlsx"]
    records = []
    for r in stat_rows(raw, files[0]):
        if (
            r["REF_DATE"] < "2021-01"
            or r["GEO"] not in GEO
            or r[IND] not in SECTORS
            or r["Statistics"] not in STATS
        ):
            continue
        sector = SECTORS[r[IND]]
        geo = r["GEO"]
        if geo != "Canada" and (
            sector not in ["All industries", "Health care and social assistance"]
            or (r["REF_DATE"] < "2023-01" and geo != "Manitoba")
        ):
            continue
        assert r["SCALAR_FACTOR"] == "units"
        metric = STATS[r["Statistics"]]
        unit = {"Job vacancy rate": "percent", "Offered hourly wage": "CAD per hour"}.get(
            metric, "count"
        )
        records.append(stat_record(files[0], r, quarter(r["REF_DATE"]), sector, metric, unit))
    workbook = openpyxl.load_workbook(raw / files[1], read_only=True, data_only=True)
    for i, r in enumerate(workbook["StaffingData"].iter_rows(max_col=12, values_only=True), 1):
        if i < 3 or not r[0]:
            continue
        _, geo, period, area, *_ = r
        if area != "Total" and geo not in [AGG, "Manitoba"]:
            continue
        for col, metric, unit, mult in [
            (6, "Calculated FTEs", "FTE", 1),
            (7, "Overtime hours", "hours", 1),
            (8, "Regular worked hours", "hours", 1),
            (9, "Overtime rate", "percent", 100),
            (12, "Paid sick leave hours", "hours", 1),
        ]:
            records.append(
                cihi_record(
                    files[1],
                    "StaffingData",
                    i,
                    col,
                    period,
                    geo,
                    area,
                    metric,
                    r[col - 1],
                    unit,
                    mult,
                )
            )
    workbook.close()
    workbook = openpyxl.load_workbook(raw / files[2], read_only=True, data_only=True)
    for n in range(2, 15):
        sheet = workbook[f"Table {n}"]
        geo = " ".join(sheet.cell(2, 4).value.split(":")[0].split())
        prof = None
        for i, r in enumerate(sheet.iter_rows(max_col=4, values_only=True), 1):
            if i < 3:
                continue
            if r[0]:
                prof = str(r[0]).strip()
            if prof in PROFESSIONS and isinstance(r[1], int) and 2020 <= r[1] <= 2024:
                records.append(
                    cihi_record(
                        files[2],
                        sheet.title,
                        i,
                        4,
                        str(r[1]),
                        geo,
                        prof,
                        "Supply per 100,000",
                        r[3],
                        "per 100,000 population",
                    )
                )
    workbook.close()
    return records, files


def workforce(raw, output):
    records, files = load_workforce_records(raw)
    idx = lookup(records)
    sid, ssid, osid = [SOURCES[f][0] for f in files]
    q = sorted({r["period"] for r in records if r["source_id"] == sid})
    last = q[-1]
    recent = [p for p in q if p >= "2023 Q1"]
    sectors = list(SECTORS.values())

    def get(source, period, geo, dim, metric):
        return idx.get((source, period, geo, dim, metric))

    views = []
    scope = "Quarterly, unadjusted estimates. The job vacancy rate is vacancies divided by vacancies plus payroll employees. Offered wages apply to vacant jobs, in current Canadian dollars. Published quality flags are retained."
    for metric, digits in [
        ("Job vacancy rate", 1),
        ("Job vacancies", 0),
        ("Offered hourly wage", 2),
        ("Payroll employees", 0),
    ]:
        rows = [
            dashrow(r, p, label=dim)
            for p in q
            for dim in sectors
            if (r := get(sid, p, "Canada", dim, metric))
        ]
        views.append(
            view(
                f"{metric} by industry · Canada",
                "Labour market by industry",
                rows,
                scope,
                digits=digits,
            )
        )
    for dim in ["Health care and social assistance", "All industries"]:
        for metric, digits in [
            ("Job vacancy rate", 1),
            ("Job vacancies", 0),
            ("Offered hourly wage", 2),
        ]:
            rows = [
                dashrow(r, p) for p in recent for geo in GEO if (r := get(sid, p, geo, dim, metric))
            ]
            views.append(
                view(
                    f"{metric} · {dim}", "Labour market by jurisdiction", rows, scope, digits=digits
                )
            )
    for metric, digits in [
        ("Job vacancy rate", 1),
        ("Job vacancies", 0),
        ("Offered hourly wage", 2),
    ]:
        rows = []
        for geo in ["Canada", "Manitoba"]:
            for dim in ["Health care and social assistance", "All industries"]:
                selection = f"{geo} · {dim}"
                for p in q:
                    if r := get(sid, p, geo, dim, metric):
                        rows.append(dashrow(r, selection, label=p))
        views.append(
            view(
                f"{metric} trend",
                "Labour market trends",
                rows,
                scope,
                chart="line",
                digits=digits,
                default="Canada · Health care and social assistance",
            )
        )
    staffing = [r for r in records if r["source_id"] == ssid]
    fiscal = sorted({r["period"] for r in staffing})
    areas = sorted({r["dimension"] for r in staffing if r["dimension"] != "Total"})
    geos = list(dict.fromkeys(r["geography"] for r in staffing if r["dimension"] == "Total"))
    staff_note = "CIHI Canadian MIS Database, hospital personnel excluding physician hours. Quebec and Nunavut do not report. Participating jurisdictions can vary across years. Overtime rate is defined as overtime hours divided by overtime plus regular worked hours, excluding purchased hours. We retain CIHI’s published rates. Recomputed rates differ by up to 0.025 percentage points in this extract."
    for metric, digits in [
        ("Overtime rate", 2),
        ("Paid sick leave hours", 0),
        ("Calculated FTEs", 0),
    ]:
        rows = [
            dashrow(r, p)
            for p in fiscal
            for geo in geos
            if (r := get(ssid, p, geo, "Total", metric))
        ]
        views.append(
            view(
                f"Hospital {metric.lower()} by jurisdiction",
                "Hospital staffing",
                rows,
                staff_note
                + " Sick leave hours are paid benefit hours, and FTEs are calculated from earned hours.",
                digits=digits,
            )
        )
    rows = []
    for geo in [AGG, "Manitoba"]:
        for p in fiscal:
            for area in areas:
                if r := get(ssid, p, geo, area, "Overtime rate"):
                    rows.append(dashrow(r, f"{geo} · {p}", label=area))
    views.append(
        view(
            "Overtime rate by hospital service area",
            "Hospital staffing",
            rows,
            staff_note + " Service areas include all unit-producing and support personnel.",
            digits=2,
            default=f"{AGG} · {fiscal[-1]}",
        )
    )
    # Derived sick leave hours per FTE; disclose denominator and source cells.
    rows = []
    for p in fiscal:
        for geo in geos:
            a = get(ssid, p, geo, "Total", "Paid sick leave hours")
            b = get(ssid, p, geo, "Total", "Calculated FTEs")
            if not a or not b:
                continue
            value = (
                a["value"] / b["value"]
                if a["value"] is not None and b["value"] is not None and b["value"] > 0
                else None
            )
            item = dashrow(
                a,
                p,
                reference=f"{a['source_reference']} / {b['source_reference']}",
                status="Calculated" if value is not None else "Unavailable",
                note="Paid sick leave hours divided by calculated FTEs; descriptive ratio.",
            )
            item.update(value=value, unit="hours per calculated FTE")
            rows.append(item)
    views.append(
        view(
            "Paid sick leave hours per calculated FTE",
            "Hospital staffing",
            rows,
            "Calculated paid sick leave hours per FTE, using published CIHI totals. This ratio is a standardized descriptive measure; it does not measure individual absenteeism. Coverage may vary by year.",
            digits=1,
        )
    )
    for prof in PROFESSIONS:
        rows = [
            dashrow(r, p)
            for p in map(str, range(2020, 2025))
            for geo in GEO[1:]
            if (r := get(osid, p, geo, prof, "Supply per 100,000"))
        ]
        views.append(
            view(
                f"{prof} per 100,000 residents",
                "Health professional supply",
                rows,
                "CIHI published supply density. Differences in registration, definitions and coverage matter. Asterisk values are retained with caution. These counts reflect supply, not necessarily active direct-care employment.",
                digits=1,
            )
        )
    # Recompute vacancy rate where all three measures are present; allowances for rounded estimates.
    ratechecks = 0
    maxdiff = 0
    for r in records:
        if r["metric"] == "Job vacancy rate" and r["value"] is not None:
            a = get(sid, r["period"], r["geography"], r["dimension"], "Job vacancies")
            b = get(sid, r["period"], r["geography"], r["dimension"], "Payroll employees")
            if (
                a
                and b
                and a["value"] is not None
                and b["value"] is not None
                and a["value"] + b["value"]
            ):
                diff = abs(r["value"] - 100 * a["value"] / (a["value"] + b["value"]))
                maxdiff = max(maxdiff, diff)
                assert diff < 0.25, (r, diff)
                ratechecks += 1
    otchecks = 0
    maxotdiff = 0
    for r in staffing:
        if r["metric"] != "Overtime rate" or r["value"] is None:
            continue
        a = get(ssid, r["period"], r["geography"], r["dimension"], "Overtime hours")
        b = get(ssid, r["period"], r["geography"], r["dimension"], "Regular worked hours")
        if (
            a
            and b
            and a["value"] is not None
            and b["value"] is not None
            and a["value"] + b["value"]
        ):
            diff = abs(r["value"] - 100 * a["value"] / (a["value"] + b["value"]))
            maxotdiff = max(maxotdiff, diff)
            assert diff < 0.03, (r, diff)
            otchecks += 1
    w = lambda geo, dim, metric: get(sid, last, geo, dim, metric)["value"]
    c = w("Canada", "All industries", "Job vacancies")
    h = w("Canada", "Health care and social assistance", "Job vacancies")
    mb = w("Manitoba", "Health care and social assistance", "Job vacancy rate")
    national = w("Canada", "Health care and social assistance", "Job vacancy rate")
    latest_staff = get(ssid, fiscal[-1], AGG, "Total", "Overtime rate")["value"]
    mb_staff = get(ssid, fiscal[-1], "Manitoba", "Total", "Overtime rate")
    mb_staff = mb_staff["value"] if mb_staff else None
    findings = [
        f"In {last}, Canada reported {c:,.0f} vacancies across all industries. Health care and social assistance accounted for {h:,.0f}, or {h/c*100:.1f}% of the total (using published estimates).",
        f"Manitoba’s health care and social assistance vacancy rate was {mb:.1f}% in {last}, compared with {national:.1f}% nationally. These are unadjusted estimates for the same quarter.",
        f"Among CIHI reporting jurisdictions, overtime represented {latest_staff:.2f}% of regular plus overtime hospital worked hours in {fiscal[-1]}. Reporting coverage differs from the labour market survey.",
    ]
    p = {
        "id": "workforce",
        "title": "Canadian workforce and labour market analytics",
        "category": "Workforce & operations",
        "type": "real",
        "group": "business",
        "period": f"2020–2026 · latest periods vary",
        "question": "Where are staffing pressures concentrated across Canadian industries and jurisdictions, and what can hospital staffing and health professional supply indicators add to workforce planning?",
        "summary": "This project analyses quarterly vacancies, offered wages and payroll employment across selected industries and jurisdictions. Separate CIHI views examine hospital overtime, paid sick leave, calculated staffing capacity and health professional supply.",
        "methods": [
            "Source-linked extraction of Statistics Canada and CIHI aggregates",
            "SQL comparisons across industries, regions and reporting periods",
            "Reconciliation of published vacancy and overtime rates to source counts",
            "Separate industry, hospital staffing and professional supply analyses",
        ],
        "tools": ["Python", "SQL", "Power BI project", "Web dashboard"],
        "coverage": f"{len(records):,} source observations from Statistics Canada quarterly data (2021 Q1 to {last}), CIHI hospital staffing (2020–2021 to {fiscal[-1]}) and 2020–2024 professional supply. Regional labour market comparisons start in 2023.",
        "source": "Statistics Canada Table 14-10-0442-01; CIHI Health Workforce Quick Stats and Overview",
        "sourceUrl": SOURCES[files[0]][2],
        "repoUrl": "resources/workforce/workflow.zip",
        "evidence": "resources/workforce/methodology.html",
        "sourceLinks": [
            {"name": "CIHI hospital staffing and workforce", "url": SOURCES[files[1]][2]},
            {"name": "CIHI health professional supply", "url": SOURCES[files[2]][2]},
        ],
        "statusText": "Real public aggregate statistics with original quality and suppression flags. Calculated ratios are clearly labelled. The survey and CIHI sources have different populations and reference periods.",
        "limits": "Quarterly vacancy estimates are unadjusted for seasonality; compare the same quarter across years. Offered wages refer to vacant jobs and are expressed in nominal CAD. CIHI staffing excludes physician hours and Quebec and Nunavut do not report to CMDB. Coverage may change over time. CIHI supply estimates are not equivalent to employed FTEs, and the different source populations cannot establish a direct staffing shortfall.",
        "findings": findings,
        "highlight": f"Canadian vacancies · {last}",
        "highlightValue": f"{c:,.0f}",
        "cards": [
            {"value": f"{c:,.0f}", "label": f"Canada job vacancies · {last}"},
            {
                "value": f"{mb:.1f}%",
                "label": f"Manitoba health and social assistance vacancy rate · {last}",
            },
            {
                "value": f"{latest_staff:.2f}%",
                "label": f"Overtime among CIHI reporting jurisdictions · {fiscal[-1]}",
            },
        ],
        "views": views,
    }
    sql = Path(__file__).with_name("analysis.sql").read_text(encoding="utf-8")
    validation = {
        "vacancy_formula_checks": ratechecks,
        "max_vacancy_rate_difference_pp": maxdiff,
        "overtime_formula_checks": otchecks,
        "max_overtime_rate_difference_pp": maxotdiff,
        "source_observations": len(records),
        "withheld": sum(r["value"] is None for r in records),
    }
    return p, records, sql, validation, files, []


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--project", choices=["workforce", "all"], default="workforce")
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    if args.download:
        args.raw_dir.mkdir(parents=True, exist_ok=True)
        for filename, (_, download_url, _) in SOURCES.items():
            target = args.raw_dir / filename
            if not target.exists():
                request = Request(download_url, headers={"User-Agent": "Portfolio data analysis"})
                with urlopen(request, timeout=120) as response:
                    target.write_bytes(response.read())
    folder = args.output_dir / "workforce"
    folder.mkdir(parents=True, exist_ok=True)
    project, records, sql, validation, files, extra_tables = workforce(args.raw_dir, folder)
    write_csv(folder / "data.csv", records, FIELDS)
    save_json(folder / "source_manifest.json", source_manifest(args.raw_dir, files))
    save_json(folder / "validation.json", validation)
    for name, rows in extra_tables:
        write_csv(folder / (name + ".csv"), rows)
    (folder / "analysis.sql").write_text(sql)
    run_sql(folder)
    save_json(folder / "project.json", project)
    print(
        "workforce:",
        len(records),
        "source records;",
        len(project["views"]),
        "dashboard views",
        flush=True,
    )


if __name__ == "__main__":
    main()
