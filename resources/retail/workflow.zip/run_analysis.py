"""Execute the published SQL against the included CSV extracts. Python standard library only."""
import csv, json, sqlite3, sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
conn=sqlite3.connect(':memory:');conn.row_factory=sqlite3.Row
for name in ['observations','forecasts','backtest','model_scores','seasonality','yoy']:
    file=root/('data.csv' if name=='observations' else name+'.csv')
    if not file.exists():continue
    with file.open(encoding='utf-8',newline='') as stream: records=list(csv.DictReader(stream))
    fields=list(records[0]); numeric={'value','forecast_cad_thousands','actual_cad_thousands','horizon_months','wape_percent','mae_cad_millions','seasonal_index','yoy_percent','current_cad_thousands','prior_cad_thousands'}
    conn.execute('CREATE TABLE '+name+' ('+','.join('"'+f+'" '+('REAL' if f in numeric else 'TEXT') for f in fields)+')')
    conn.executemany('INSERT INTO '+name+' VALUES ('+','.join('?' for _ in fields)+')',[[float(r[f]) if f in numeric and r[f] else None if f in numeric else r[f] for f in fields] for r in records])
queries=[q.strip() for q in (root/'analysis.sql').read_text().split(';') if any(line.strip() and not line.strip().startswith('--') for line in q.splitlines())]
results=[[dict(r) for r in conn.execute(q)] for q in queries]
(root/'analysis_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print('Executed',len(results),'SQL analyses')
