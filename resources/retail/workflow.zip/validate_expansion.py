"""Independently reconcile every distributed record with original official files.
Usage: python validate_expansion.py --raw-dir raw --output-dir output --project all
"""
import argparse, csv, io, hashlib, json, zipfile, math
from pathlib import Path
from collections import defaultdict
import openpyxl
import numpy as np

def read(path):
 with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def close(a,b):return math.isclose(float(a),float(b),rel_tol=1e-10,abs_tol=1e-8)

def validate(name,raw,folder):
 rows=read(folder/'data.csv');sources=defaultdict(list)
 for r in rows:sources[r['source_file']].append(r)
 manifest=json.loads((folder/'source_manifest.json').read_text())
 for m in manifest['sources']:
  assert hashlib.sha256((raw/m['file']).read_bytes()).hexdigest()==m['sha256']
 count=0
 for filename,records in sources.items():
  if filename.endswith('.zip'):
   key=lambda r:(r['VECTOR'],r['COORDINATE'],r['REF_DATE'])
   wanted={tuple(r['source_reference'].split(' · ')):r for r in records};assert len(wanted)==len(records)
   with zipfile.ZipFile(raw/filename) as z:
    f=next(n for n in z.namelist() if n.endswith('.csv') and 'MetaData' not in n)
    with z.open(f) as stream:
     for source in csv.DictReader(io.TextIOWrapper(stream,encoding='utf-8-sig')):
      k=key(source)
      if k not in wanted:continue
      r=wanted.pop(k);assert r['raw_value']==source['VALUE'] and r['raw_flag']==source['STATUS'] and r['geography']==source['GEO']
      assert (not r['value'] and not source['VALUE']) or close(r['value'],source['VALUE'])
      if name=='retail':assert r['period']==source['REF_DATE'] and r['dimension']==source['Adjustments'] and source['SCALAR_FACTOR']=='thousands'
      else:
       q=f"{source['REF_DATE'][:4]} Q{(int(source['REF_DATE'][5:7])-1)//3+1}";assert r['period']==q and source['SCALAR_FACTOR']=='units'
      count+=1
   assert not wanted,len(wanted)
  else:
   w=openpyxl.load_workbook(raw/filename,read_only=False,data_only=True)
   for r in records:
    sheet,cell=r['source_reference'].split('!');val=w[sheet][cell].value;assert str(val if val is not None else '')==r['raw_value'],(r,val)
    try:number=float(str(val).rstrip('*'))
    except ValueError:number=None
    if number is None:assert r['value']==''
    else:assert close(r['value'],number*(100 if r['metric']=='Overtime rate' else 1))
    if filename=='cihi-quickstats.xlsx':
     i=w[sheet][cell].row;assert (r['geography'],r['period'],r['dimension'])==tuple(w[sheet].cell(i,c).value for c in (2,3,4))
    else:
     i=w[sheet][cell].row;assert str(w[sheet].cell(i,2).value)==r['period'];assert ' '.join(w[sheet].cell(2,4).value.split(':')[0].split())==r['geography']
    count+=1
   w.close()
 assert count==len(rows)
 val=json.loads((folder/'validation.json').read_text());val['independently_matched_source_records']=count;val['status']='passed'
 if name=='retail':
  back=read(folder/'backtest.csv');pred=read(folder/'forecasts.csv');scores=read(folder/'model_scores.csv');by=defaultdict(list)
  actual={(r['geography'],r['period']):float(r['value']) for r in rows if r['dimension']=='Unadjusted'}
  for r in back:
   assert r['training_through']<r['target_month']
   assert close(actual[(r['geography'],r['target_month'])],r['actual_cad_thousands'])
   assert ('2023-10'<=r['target_month']<='2025-09') if r['phase']=='Validation' else ('2025-10'<=r['target_month']<='2026-09')
   by[(r['geography'],r['phase'],r['model'])].append(r)
  for s in scores:
   group=by[(s['geography'],s['phase'],s['model'])];a=np.array([float(r['actual_cad_thousands']) for r in group]);p=np.array([float(r['forecast_cad_thousands']) for r in group]);assert close(s['wape_percent'],100*abs(a-p).sum()/abs(a).sum());assert close(s['mae_cad_millions'],abs(a-p).mean()/1000)
  for g in {r['geography'] for r in pred}:
   selected=[r for r in scores if r['geography']==g and r['phase']=='Validation'];best=min(selected,key=lambda r:float(r['wape_percent']))['model'];group=[r for r in pred if r['geography']==g];assert len(group)==6 and all(r['model']==best and r['month']>'2026-09' and r['training_through']=='2026-09' and r['status']=='Forecast' for r in group)
  val['independently_recomputed_model_scores']=len(scores);val['forecast_rows_checked']=len(pred)
 (folder/'validation.json').write_text(json.dumps(val,indent=2)+'\n')
 print(name,'PASS',count,'independent source matches')

def main():
 p=argparse.ArgumentParser();p.add_argument('--raw-dir',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--project',choices=['workforce','retail','all'],default='all');a=p.parse_args()
 for name in ['workforce','retail']:
  if a.project in (name,'all'):validate(name,a.raw_dir,a.output_dir/name)
if __name__=='__main__':main()
