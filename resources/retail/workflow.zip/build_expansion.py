"""Build the monthly retail sales comparisons, seasonal indices and forecasts.

Use --download to obtain the original public files. The source manifest retains their hashes.
"""

import argparse
import csv
import io
import json
import zipfile
import hashlib
from pathlib import Path
from urllib.request import Request, urlopen
from run_analysis import run as run_sql
import math
from datetime import date
import numpy as np

RETRIEVED = "2026-11-22"

IND = "North American Industry Classification System (NAICS)"

GEO = [
    "Canada",
    "Newfoundland and Labrador",
    "Prince Edward Island",
    "Nova Scotia",
    "New Brunswick",
    "Quebec",
    "Ontario",
    "Manitoba",
    "Saskatchewan",
    "Alberta",
    "British Columbia",
    "Yukon",
    "Northwest Territories",
    "Nunavut",
]

SOURCES = {
    "retail-statcan.zip": (
        "Statistics Canada 20-10-0056-01",
        "https://www150.statcan.gc.ca/n1/tbl/csv/20100056-eng.zip",
        "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=2010005601",
    )
}

FIELDS = [
    "source_id",
    "source_file",
    "period",
    "geography",
    "dimension",
    "metric",
    "value",
    "unit",
    "status",
    "raw_value",
    "raw_flag",
    "source_reference",
    "source_url",
]

FLAGS = {
    "A": "Published · excellent",
    "B": "Published · very good",
    "C": "Published · good",
    "D": "Published · acceptable",
    "E": "Use with caution",
    "F": "Too unreliable to publish",
    "x": "Suppressed",
    "..": "Unavailable",
    "...": "Not applicable",
    "": "Published",
}


def as_num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def stat_rows(raw, file):
    with zipfile.ZipFile(raw / file) as z:
        n = next(n for n in z.namelist() if n.endswith(".csv") and "MetaData" not in n)
        with z.open(n) as f:
            yield from csv.DictReader(io.TextIOWrapper(f, encoding="utf-8-sig"))


def record(file, period, geo, dim, metric, value, unit, status, raw_val, flag, reference):
    source, _, url = SOURCES[file]
    return {
        "source_id": source,
        "source_file": file,
        "period": period,
        "geography": geo,
        "dimension": dim,
        "metric": metric,
        "value": value,
        "unit": unit,
        "status": status,
        "raw_value": "" if raw_val is None else str(raw_val),
        "raw_flag": str(flag or ""),
        "source_reference": reference,
        "source_url": url,
    }


def stat_record(file, r, period, dim, metric, unit, divisor=1):
    val = as_num(r["VALUE"])
    flag = r["STATUS"]
    status = FLAGS.get(flag, flag or "Published")
    if val is None:
        status = FLAGS.get(flag, "Unavailable") if flag else "Unavailable"
    return record(
        file,
        period,
        r["GEO"],
        dim,
        metric,
        None if val is None else val / divisor,
        unit,
        status,
        r["VALUE"],
        flag,
        f"{r['VECTOR']} · {r['COORDINATE']} · {r['REF_DATE']}",
    )


def write_csv(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def source_manifest(raw, files):
    return {
        "source_retrieval_date": RETRIEVED,
        "sources": [
            {
                "file": p,
                "publisher": SOURCES[p][0],
                "download_url": SOURCES[p][1],
                "reference_url": SOURCES[p][2],
                "sha256": hashlib.sha256((raw / p).read_bytes()).hexdigest(),
                "bytes": (raw / p).stat().st_size,
            }
            for p in files
        ],
    }


def dashrow(row, period, label=None, value=None, status=None, reference=None, note=None):
    return {
        "year": period,
        "label": label or row["geography"],
        "value": row["value"] if value is None else value,
        "unit": row["unit"],
        "status": status or row["status"],
        "sourceId": row["source_id"],
        "sourceRef": reference or row["source_reference"],
        "sourceUrl": row["source_url"],
        "n": reference or row["source_reference"],
        **({"note": note} if note else {}),
    }


def view(name, section, rows, explain, chart="bar", digits=1, default=None):
    assert rows and all(r["status"] and r["sourceRef"] for r in rows)
    years = list(dict.fromkeys(r["year"] for r in rows))
    return {
        "name": name,
        "section": section,
        "chart": chart,
        "digits": digits,
        "years": years,
        "defaultYear": default or years[-1],
        "rows": rows,
        "explain": explain,
        "denominatorLabel": "Source reference",
    }


def lookup(rows):
    d = {}
    for r in rows:
        key = tuple(r[k] for k in ("source_id", "period", "geography", "dimension", "metric"))
        assert key not in d, key
        d[key] = r
    return d


def forecast(sales, method, horizon):
    if method == "Seasonal naive":
        return np.asarray([sales[-12 + month % 12] for month in range(horizon)], dtype=float)

    # A linear trend and calendar-month indicators explain log sales.
    def design(months):
        return np.column_stack(
            [np.ones(len(months)), months / 12]
            + [(months % 12 == month).astype(float) for month in range(1, 12)]
        )

    training_months = np.arange(len(sales))
    coefficients = np.linalg.lstsq(design(training_months), np.log(sales), rcond=None)[0]
    future_months = np.arange(len(sales), len(sales) + horizon)
    return np.exp(design(future_months) @ coefficients)


def make_months(start_yr, start_m, n):
    return [f"{start_yr+(start_m-1+i)//12:04d}-{(start_m-1+i)%12+1:02d}" for i in range(n)]


def score(actual, pred):
    return {
        "wape_percent": float(100 * np.abs(actual - pred).sum() / np.abs(actual).sum()),
        "mae_cad_millions": float(np.mean(np.abs(actual - pred)) / 1000),
    }


def load_retail_records(raw):
    file = "retail-statcan.zip"
    records = []
    for r in stat_rows(raw, file):
        if (
            r["GEO"] not in GEO
            or r[IND] != "Retail trade [44-45]"
            or r["Sales"] != "Total retail sales"
        ):
            continue
        if r["Adjustments"] == "Unadjusted" or (
            r["Adjustments"] == "Seasonally adjusted" and r["REF_DATE"] >= "2025-10"
        ):
            assert r["SCALAR_FACTOR"] == "thousands"
            records.append(
                stat_record(
                    file, r, r["REF_DATE"], r["Adjustments"], "Retail sales", "CAD thousands"
                )
            )
    return records, file


def evaluate_forecasts(idx, sid, dates, future):
    """Score the models on separate time windows, then refit the selected model."""
    last = dates[-1]
    predictions = []
    scores = []
    backtests = []
    models = ["Seasonal naive", "Log trend + month effects"]
    for geo in GEO:
        y = np.array([idx[(sid, p, geo, "Unadjusted", "Retail sales")]["value"] for p in dates])
        assert len(y) == 117 and np.isfinite(y).all() and (y > 0).all()
        # Four validation windows of six months, Oct 2023–Sep 2025, then two untouched holdout windows Oct 2025–Sep 2026.
        scores_geo = {}
        for model in models:
            for phase, origins in [("Validation", [81, 87, 93, 99]), ("Holdout", [105, 111])]:
                actual = np.concatenate([y[o : o + 6] for o in origins])
                window_predictions = [forecast(y[:origin], model, 6) for origin in origins]
                pred = np.concatenate(window_predictions)
                s = score(actual, pred)
                scores_geo[(phase, model)] = s
                for o, window in zip(origins, window_predictions):
                    for k, predicted in enumerate(window):
                        backtests.append(
                            {
                                "geography": geo,
                                "phase": phase,
                                "model": model,
                                "training_through": dates[o - 1],
                                "target_month": dates[o + k],
                                "horizon_months": k + 1,
                                "actual_cad_thousands": y[o + k],
                                "forecast_cad_thousands": predicted,
                            }
                        )
        selected = min(models, key=lambda m: scores_geo[("Validation", m)]["wape_percent"])
        for model in models:
            for phase in ("Validation", "Holdout"):
                scores.append(
                    {
                        "geography": geo,
                        "phase": phase,
                        "model": model,
                        "selected": model == selected,
                        **scores_geo[(phase, model)],
                    }
                )
        for m, v in zip(future, forecast(y, selected, 6)):
            assert math.isfinite(v) and v > 0
            predictions.append(
                {
                    "geography": geo,
                    "month": m,
                    "model": selected,
                    "forecast_cad_thousands": float(v),
                    "training_through": last,
                    "status": "Forecast",
                }
            )
    return predictions, scores, backtests, models


def retail(raw, output):
    records, file = load_retail_records(raw)
    idx = lookup(records)
    sid = SOURCES[file][0]
    dates = sorted({r["period"] for r in records if r["dimension"] == "Unadjusted"})
    assert dates == make_months(2017, 1, 117)
    last = dates[-1]
    future = make_months(2026, 10, 6)
    predictions, scores, backtests, models = evaluate_forecasts(idx, sid, dates, future)
    views = []
    rows = []
    for geo in GEO:
        for period in dates[-24:]:
            row = idx[(sid, period, geo, "Unadjusted", "Retail sales")]
            r = dashrow(row, geo, label=period, value=row["value"] / 1e6)
            r["unit"] = "CAD billions"
            rows.append(r)
        for pred in predictions:
            if pred["geography"] != geo:
                continue
            row = idx[(sid, last, geo, "Unadjusted", "Retail sales")]
            r = dashrow(
                row,
                geo,
                label=pred["month"],
                value=pred["forecast_cad_thousands"] / 1e6,
                status="Forecast",
                reference=f"{pred['model']} · trained through {last}",
                note="Portfolio model using past published unadjusted sales. See workflow and holdout results.",
            )
            r["unit"] = "CAD billions"
            rows.append(r)
    views.append(
        view(
            "Monthly sales and six-month forecast (CAD billions)",
            "Forecast and historical trends",
            rows,
            "Unadjusted nominal monthly sales. The teal line shows published observations; the dashed line shows portfolio-model forecasts for October 2026 to March 2027. Models are chosen using pre-holdout rolling-origin validation. Forecasts are point estimates, not official Statistics Canada predictions.",
            chart="line",
            digits=3,
            default="Canada",
        )
    )
    rows = []
    for p in dates[-12:]:
        for geo in GEO:
            if r := idx.get((sid, p, geo, "Seasonally adjusted", "Retail sales")):
                d = dashrow(r, p, value=r["value"] / 1e6 if r["value"] is not None else None)
                d["unit"] = "CAD billions"
                rows.append(d)
    views.append(
        view(
            "Seasonally adjusted sales by jurisdiction (CAD billions)",
            "Regional comparisons",
            rows,
            "Published seasonally adjusted monthly sales in current Canadian dollars. Canada is the separate benchmark; provincial/territorial values need not sum exactly to it because adjustment and rounding may differ.",
            digits=3,
        )
    )
    rows = []
    for geo in GEO:
        for period in dates[-24:]:
            r = idx[(sid, period, geo, "Unadjusted", "Retail sales")]
            d = dashrow(r, geo, label=period, value=r["value"] / 1e6)
            d["unit"] = "CAD billions"
            rows.append(d)
    views.append(
        view(
            "Published unadjusted sales trend (CAD billions)",
            "Forecast and historical trends",
            rows,
            "Unadjusted sales in nominal Canadian dollars. Month-to-month fluctuations include seasonal effects, so the next view compares the same month in prior years.",
            chart="line",
            digits=3,
            default="Canada",
        )
    )
    # Seasonal index normalizes five full years within each geography: mean(month/annual mean)*100.
    rows = []
    seasonal = []
    for geo in GEO:
        vals = np.array(
            [
                idx[(sid, p, geo, "Unadjusted", "Retail sales")]["value"]
                for p in dates
                if "2021-01" <= p <= "2025-12"
            ]
        ).reshape(5, 12)
        indices = (vals / vals.mean(axis=1, keepdims=True)).mean(axis=0) * 100
        assert abs(indices.mean() - 100) < 1e-8
        src = idx[(sid, "2025-12", geo, "Unadjusted", "Retail sales")]
        for i, val in enumerate(indices):
            month = date(2025, i + 1, 1).strftime("%b")
            seasonal.append({"geography": geo, "month": i + 1, "seasonal_index": float(val)})
            d = dashrow(
                src,
                geo,
                label=month,
                value=float(val),
                status="Calculated",
                reference=f"{src['source_reference'].split(' · ')[0]} · 2021–2025",
            )
            d["unit"] = "index (annual monthly mean = 100)"
            rows.append(d)
    views.append(
        view(
            "Monthly seasonal sales index (average = 100)",
            "Seasonality",
            rows,
            "Average of each month’s sales divided by its own year’s monthly mean, across five complete years (2021–2025). A value above 100 indicates a historically stronger-than-average month, not a growth rate.",
            digits=1,
            default="Canada",
        )
    )
    # Negative YoY values need a true diverging bar renderer; include source references for both months.
    rows = []
    yoy = []
    for p in dates[-12:]:
        prior = f"{int(p[:4])-1:04d}-{p[5:]}"
        for geo in GEO:
            a = idx[(sid, p, geo, "Unadjusted", "Retail sales")]
            b = idx[(sid, prior, geo, "Unadjusted", "Retail sales")]
            v = 100 * (a["value"] / b["value"] - 1)
            yoy.append(
                {
                    "geography": geo,
                    "month": p,
                    "yoy_percent": v,
                    "current_cad_thousands": a["value"],
                    "prior_cad_thousands": b["value"],
                }
            )
            d = dashrow(
                a,
                p,
                value=v,
                status="Calculated",
                reference=f"{a['source_reference']} / {b['period']}",
                note="Nominal same-month year-over-year percentage change.",
            )
            d["unit"] = "percent"
            rows.append(d)
    views.append(
        view(
            "Unadjusted retail sales year-over-year change (%)",
            "Regional comparisons",
            rows,
            "Same-month year-over-year growth in nominal sales, calculated from unadjusted published sales. Negative values indicate contraction; positive values indicate growth.",
            digits=2,
        )
    )
    rows = []
    for phase in ["Validation", "Holdout"]:
        for model in models:
            for m in scores:
                if m["phase"] != phase or m["model"] != model:
                    continue
                src = idx[(sid, last, m["geography"], "Unadjusted", "Retail sales")]
                d = dashrow(
                    src,
                    f"{phase} · {model}",
                    value=m["wape_percent"],
                    status="Calculated",
                    reference=f"{model} · {phase} rolling-origin error",
                    note="Weighted absolute percentage error; lower is better.",
                )
                d["unit"] = "percent"
                rows.append(d)
    views.append(
        view(
            "Model accuracy (WAPE, lower is better)",
            "Model evaluation",
            rows,
            "WAPE = sum of absolute errors ÷ sum of actuals × 100. Validation uses four six-month rolling windows October 2023–September 2025; holdout uses two windows October 2025–September 2026. Model selection uses validation only; holdout estimates out-of-sample accuracy. Later windows train on actuals available at their origin.",
            digits=2,
            default="Holdout · Seasonal naive",
        )
    )
    chosen = [m for m in scores if m["selected"] and m["phase"] == "Holdout"]
    can = next(m for m in chosen if m["geography"] == "Canada")
    canbaseline = next(
        m
        for m in scores
        if m["geography"] == "Canada" and m["phase"] == "Holdout" and m["model"] == "Seasonal naive"
    )
    canlatest = idx[(sid, last, "Canada", "Seasonally adjusted", "Retail sales")]["value"] / 1e6
    mbforecast = next(
        p for p in predictions if p["geography"] == "Manitoba" and p["month"] == future[0]
    )
    peak = max(
        [x for x in seasonal if x["geography"] == "Canada"], key=lambda x: x["seasonal_index"]
    )
    month = date(2025, peak["month"], 1).strftime("%B")
    p = {
        "id": "retail",
        "title": "Canadian retail sales forecasting",
        "category": "Commercial & predictive analytics",
        "type": "real",
        "group": "business",
        "period": "2017–2026 actuals · 2026–2027 forecast",
        "question": "How do Canadian retail sales vary by region and season, and how accurately can established time-series baselines forecast the next six months?",
        "summary": "This project analyses monthly retail sales across Canada and all provinces and territories, quantifies regional growth and seasonal demand patterns, and tests two forecasting methods using rolling-origin validation before producing six-month forecasts.",
        "methods": [
            "Official monthly source extraction and quality flags",
            "Time-series seasonality and year-over-year comparisons",
            "Seasonal naive and log-linear seasonal trend models",
            "Rolling-origin validation and separate holdout evaluation",
        ],
        "tools": ["Python", "SQL", "Tableau workbook", "Web dashboard"],
        "coverage": f"{len(records):,} official observations; 117 unadjusted months per jurisdiction (January 2017 to September 2026) and the latest 12 seasonally adjusted months. Six-month forecasts for all 14 geographies, including Canada separately.",
        "source": "Statistics Canada Monthly Retail Trade Survey, Table 20-10-0056-01",
        "sourceUrl": SOURCES[file][2],
        "repoUrl": "resources/retail/workflow.zip",
        "evidence": "resources/retail/methodology.html",
        "statusText": "Published nominal retail sales, with separate unadjusted and seasonally adjusted series. Historical observations, derived measures and portfolio-model forecasts are labelled explicitly.",
        "limits": "Nominal aggregate retail sales include price changes. These are broad market indicators, not individual store revenue or inventory demand. Model selection uses one historical release rather than first-release data vintages, so backtests do not establish real-time operational accuracy. Structural changes, economic shocks and revisions may affect forecasts. All future estimates are point forecasts without a probability interval.",
        "findings": [
            f"Canada’s seasonally adjusted retail sales were ${canlatest:.2f} billion in September 2026.",
            f'For Canada, the validation-selected {can["model"]} model achieved holdout WAPE of {can["wape_percent"]:.2f}%; seasonal naive holdout WAPE was {canbaseline["wape_percent"]:.2f}%. Lower is better.',
            f'Across 2021–2025, {month} had the highest average national seasonal index ({peak["seasonal_index"]:.1f}). Manitoba’s October 2026 portfolio-model forecast was ${mbforecast["forecast_cad_thousands"]/1e6:.3f} billion.',
        ],
        "highlight": f'Canada forecast holdout WAPE · {can["model"]}',
        "highlightValue": f'{can["wape_percent"]:.2f}%',
        "cards": [
            {"value": f"${canlatest:.2f}B", "label": "Canada seasonally adjusted sales · Sep 2026"},
            {"value": f'{can["wape_percent"]:.2f}%', "label": "Canada selected-model holdout WAPE"},
            {"value": "6 months", "label": "Forecast horizon · Oct 2026–Mar 2027"},
        ],
        "views": views,
    }
    sql = Path(__file__).with_name("analysis.sql").read_text(encoding="utf-8")
    validation = {
        "source_observations": len(records),
        "geographies": len(GEO),
        "monthly_observations_per_geography": 117,
        "validation_months": 24,
        "holdout_months": 12,
        "forecast_records": len(predictions),
        "backtest_records": len(backtests),
        "forecast_horizon_months": 6,
        "selection": "Minimum validation WAPE, seasonal naive tie-break. Holdout excluded from selection.",
    }
    return (
        p,
        records,
        sql,
        validation,
        [file],
        [
            ("forecasts", predictions),
            ("backtest", backtests),
            ("model_scores", scores),
            ("seasonality", seasonal),
            ("yoy", yoy),
        ],
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--project", choices=["retail", "all"], default="retail")
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    if args.download:
        args.raw_dir.mkdir(parents=True, exist_ok=True)
        for filename, (_, download_url, _) in SOURCES.items():
            target = args.raw_dir / filename
            if not target.exists():
                request = Request(download_url, headers={"User-Agent": "Portfolio data analysis"})
                with urlopen(request, timeout=120) as response:
                    target.write_bytes(response.read())
    folder = args.output_dir / "retail"
    folder.mkdir(parents=True, exist_ok=True)
    project, records, sql, validation, files, extra_tables = retail(args.raw_dir, folder)
    write_csv(folder / "data.csv", records, FIELDS)
    save_json(folder / "source_manifest.json", source_manifest(args.raw_dir, files))
    save_json(folder / "validation.json", validation)
    for name, rows in extra_tables:
        write_csv(folder / (name + ".csv"), rows)
    (folder / "analysis.sql").write_text(sql)
    run_sql(folder)
    save_json(folder / "project.json", project)
    print(
        "retail:",
        len(records),
        "source records;",
        len(project["views"]),
        "dashboard views",
        flush=True,
    )


if __name__ == "__main__":
    main()
