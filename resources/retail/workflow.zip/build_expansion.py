"""Build two reproducible portfolio projects from official Canadian public data.
Run: python build_expansion.py --raw-dir raw --output-dir output --project workforce|retail
Add --download to fetch the original public files. The source_manifest records SHA-256.
"""
import argparse,csv,io,json,math,re,sqlite3,zipfile,hashlib
from pathlib import Path
from urllib.request import Request,urlopen
from collections import defaultdict,Counter
from datetime import date
import numpy as np
import openpyxl

RETRIEVED='2026-11-22'
IND='North American Industry Classification System (NAICS)'
GEO=['Canada','Newfoundland and Labrador','Prince Edward Island','Nova Scotia','New Brunswick','Quebec','Ontario','Manitoba','Saskatchewan','Alberta','British Columbia','Yukon','Northwest Territories','Nunavut']
SOURCES={
 'workforce-statcan.zip':('Statistics Canada 14-10-0442-01','https://www150.statcan.gc.ca/n1/tbl/csv/14100442-eng.zip','https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1410044201'),
 'retail-statcan.zip':('Statistics Canada 20-10-0056-01','https://www150.statcan.gc.ca/n1/tbl/csv/20100056-eng.zip','https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=2010005601'),
 'cihi-quickstats.xlsx':('CIHI Health Workforce Quick Stats 2024','https://www.cihi.ca/sites/default/files/document/health-workforce-quickstats-2024-data-tables-en.xlsx','https://www.cihi.ca/en/the-state-of-the-health-workforce-in-canada-2024/go-in-depth-2024-health-workforce-data'),
 'cihi-overview.xlsx':('CIHI Health Workforce Overview 2020–2024','https://www.cihi.ca/sites/default/files/document/data-file/health-workforce-canada-2020-2024-overview-data-tables-en.xlsx','https://www.cihi.ca/en/health-workforce-in-canada-overview')}
SECTORS={'Total, all industries':'All industries','Health care and social assistance [62]':'Health care and social assistance','Retail trade [44-45]':'Retail trade','Manufacturing [31-33]':'Manufacturing','Construction [23]':'Construction','Accommodation and food services [72]':'Accommodation and food services','Professional, scientific and technical services [54]':'Professional, scientific and technical services','Finance and insurance [52]':'Finance and insurance'}
STATS={'Job vacancies':'Job vacancies','Payroll employees':'Payroll employees','Job vacancy rate':'Job vacancy rate','Average offered hourly wage':'Offered hourly wage'}
PROFESSIONS=['Registered nurses','Licensed practical nurses','Nurse practitioners','Physicians','Medical laboratory technologists','Paramedics']
AGG='Provinces/territories with available data'
FIELDS=['source_id','source_file','period','geography','dimension','metric','value','unit','status','raw_value','raw_flag','source_reference','source_url']
FLAGS={'A':'Published · excellent','B':'Published · very good','C':'Published · good','D':'Published · acceptable','E':'Use with caution','F':'Too unreliable to publish','x':'Suppressed','..':'Unavailable','...':'Not applicable','':'Published'}
def quarter(s):return f'{s[:4]} Q{(int(s[5:7])-1)//3+1}'
def as_num(v):
 try:return float(v)
 except (TypeError,ValueError):return None

def stat_rows(raw,file):
 with zipfile.ZipFile(raw/file) as z:
  n=next(n for n in z.namelist() if n.endswith('.csv') and 'MetaData' not in n)
  with z.open(n) as f:yield from csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig'))

def record(file,period,geo,dim,metric,value,unit,status,raw_val,flag,reference):
 source,_,url=SOURCES[file]
 return dict(zip(FIELDS,[source,file,period,geo,dim,metric,value,unit,status,'' if raw_val is None else str(raw_val),str(flag or ''),reference,url]))

def stat_record(file,r,period,dim,metric,unit,divisor=1):
 val=as_num(r['VALUE']); flag=r['STATUS'];status=FLAGS.get(flag,flag or 'Published')
 if val is None:status=FLAGS.get(flag,'Unavailable') if flag else 'Unavailable'
 return record(file,period,r['GEO'],dim,metric,None if val is None else val/divisor,unit,status,r['VALUE'],flag,f"{r['VECTOR']} · {r['COORDINATE']} · {r['REF_DATE']}")

def cihi_record(file,sheet,row,col,period,geo,dim,metric,raw_val,unit,mult=1):
 # Preserve asterisks and suppressed/not-reported symbols from CIHI.
 flag='*' if isinstance(raw_val,str) and raw_val.endswith('*') else ''
 val=as_num(raw_val.rstrip('*') if isinstance(raw_val,str) else raw_val)
 status='Use with caution' if flag else 'Published'
 if val is None:
  flag=str(raw_val or '—');status={'x':'Suppressed','n/r':'Not reported'}.get(flag,'Unavailable')
 return record(file,period,geo,dim,metric,None if val is None else val*mult,unit,status,raw_val,flag,f'{sheet}!{openpyxl.utils.get_column_letter(col)}{row}')

def write_csv(path,rows,fields=None):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
def save_json(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def source_manifest(raw,files):
 return {'source_retrieval_date':RETRIEVED,'sources':[{'file':p,'publisher':SOURCES[p][0],'download_url':SOURCES[p][1],'reference_url':SOURCES[p][2],'sha256':hashlib.sha256((raw/p).read_bytes()).hexdigest(),'bytes':(raw/p).stat().st_size} for p in files]}

def dashrow(row,period,label=None,value=None,status=None,reference=None,note=None):
 return {'year':period,'label':label or row['geography'],'value':row['value'] if value is None else value,'unit':row['unit'],'status':status or row['status'],'sourceId':row['source_id'],'sourceRef':reference or row['source_reference'],'sourceUrl':row['source_url'],'n':reference or row['source_reference'],**({'note':note} if note else {})}
def view(name,section,rows,explain,chart='bar',digits=1,default=None):
 assert rows and all(r['status'] and r['sourceRef'] for r in rows)
 years=list(dict.fromkeys(r['year'] for r in rows)); return {'name':name,'section':section,'chart':chart,'digits':digits,'years':years,'defaultYear':default or years[-1],'rows':rows,'explain':explain,'denominatorLabel':'Source reference'}
def lookup(rows):
 d={}
 for r in rows:
  key=tuple(r[k] for k in ('source_id','period','geography','dimension','metric'))
  assert key not in d,key;d[key]=r
 return d

def workforce(raw,output):
 files=['workforce-statcan.zip','cihi-quickstats.xlsx','cihi-overview.xlsx']; records=[]
 for r in stat_rows(raw,files[0]):
  if r['REF_DATE']<'2021-01' or r['GEO'] not in GEO or r[IND] not in SECTORS or r['Statistics'] not in STATS:continue
  sector=SECTORS[r[IND]];geo=r['GEO']
  if geo!='Canada' and (sector not in ['All industries','Health care and social assistance'] or (r['REF_DATE']<'2023-01' and geo!='Manitoba')):continue
  assert r['SCALAR_FACTOR']=='units'
  metric=STATS[r['Statistics']];unit={'Job vacancy rate':'percent','Offered hourly wage':'CAD per hour'}.get(metric,'count')
  records.append(stat_record(files[0],r,quarter(r['REF_DATE']),sector,metric,unit))
 workbook=openpyxl.load_workbook(raw/files[1],read_only=True,data_only=True)
 for i,r in enumerate(workbook['StaffingData'].iter_rows(max_col=12,values_only=True),1):
  if i<3 or not r[0]:continue
  _,geo,period,area,*_=r
  if area!='Total' and geo not in [AGG,'Manitoba']:continue
  for col,metric,unit,mult in [(6,'Calculated FTEs','FTE',1),(7,'Overtime hours','hours',1),(8,'Regular worked hours','hours',1),(9,'Overtime rate','percent',100),(12,'Paid sick leave hours','hours',1)]:
   records.append(cihi_record(files[1],'StaffingData',i,col,period,geo,area,metric,r[col-1],unit,mult))
 workbook.close()
 workbook=openpyxl.load_workbook(raw/files[2],read_only=True,data_only=True)
 for n in range(2,15):
  sheet=workbook[f'Table {n}'];geo=' '.join(sheet.cell(2,4).value.split(':')[0].split());prof=None
  for i,r in enumerate(sheet.iter_rows(max_col=4,values_only=True),1):
   if i<3:continue
   if r[0]:prof=str(r[0]).strip()
   if prof in PROFESSIONS and isinstance(r[1],int) and 2020<=r[1]<=2024:
    records.append(cihi_record(files[2],sheet.title,i,4,str(r[1]),geo,prof,'Supply per 100,000',r[3],'per 100,000 population'))
 workbook.close()
 idx=lookup(records); sid,ssid,osid=[SOURCES[f][0] for f in files];
 q=sorted({r['period'] for r in records if r['source_id']==sid}); last=q[-1];recent=[p for p in q if p>='2023 Q1']; sectors=list(SECTORS.values())
 def get(source,period,geo,dim,metric):return idx.get((source,period,geo,dim,metric))
 views=[];scope='Quarterly, unadjusted estimates. The job vacancy rate is vacancies divided by vacancies plus payroll employees. Offered wages apply to vacant jobs, in current Canadian dollars. Published quality flags are retained.'
 for metric,digits in [('Job vacancy rate',1),('Job vacancies',0),('Offered hourly wage',2),('Payroll employees',0)]:
  rows=[dashrow(r,p,label=dim) for p in q for dim in sectors if (r:=get(sid,p,'Canada',dim,metric))]
  views.append(view(f'{metric} by industry · Canada','Labour market by industry',rows,scope,digits=digits))
 for dim in ['Health care and social assistance','All industries']:
  for metric,digits in [('Job vacancy rate',1),('Job vacancies',0),('Offered hourly wage',2)]:
   rows=[dashrow(r,p) for p in recent for geo in GEO if (r:=get(sid,p,geo,dim,metric))]
   views.append(view(f'{metric} · {dim}', 'Labour market by jurisdiction',rows,scope,digits=digits))
 for metric,digits in [('Job vacancy rate',1),('Job vacancies',0),('Offered hourly wage',2)]:
  rows=[]
  for geo in ['Canada','Manitoba']:
   for dim in ['Health care and social assistance','All industries']:
    selection=f'{geo} · {dim}'
    for p in q:
     if r:=get(sid,p,geo,dim,metric):rows.append(dashrow(r,selection,label=p))
  views.append(view(f'{metric} trend','Labour market trends',rows,scope,chart='line',digits=digits,default='Canada · Health care and social assistance'))
 staffing=[r for r in records if r['source_id']==ssid];fiscal=sorted({r['period'] for r in staffing});areas=sorted({r['dimension'] for r in staffing if r['dimension']!='Total'});geos=list(dict.fromkeys(r['geography'] for r in staffing if r['dimension']=='Total'))
 staff_note='CIHI Canadian MIS Database, hospital personnel excluding physician hours. Quebec and Nunavut do not report. Participating jurisdictions can vary across years. Overtime rate is defined as overtime hours divided by overtime plus regular worked hours, excluding purchased hours. We retain CIHI’s published rates. Recomputed rates differ by up to 0.025 percentage points in this extract.'
 for metric,digits in [('Overtime rate',2),('Paid sick leave hours',0),('Calculated FTEs',0)]:
  rows=[dashrow(r,p) for p in fiscal for geo in geos if (r:=get(ssid,p,geo,'Total',metric))]
  views.append(view(f'Hospital {metric.lower()} by jurisdiction','Hospital staffing',rows,staff_note+' Sick leave hours are paid benefit hours, and FTEs are calculated from earned hours.',digits=digits))
 rows=[]
 for geo in [AGG,'Manitoba']:
  for p in fiscal:
   for area in areas:
    if r:=get(ssid,p,geo,area,'Overtime rate'):rows.append(dashrow(r,f'{geo} · {p}',label=area))
 views.append(view('Overtime rate by hospital service area','Hospital staffing',rows,staff_note+' Service areas include all unit-producing and support personnel.',digits=2,default=f'{AGG} · {fiscal[-1]}'))
 # Derived sick leave hours per FTE; disclose denominator and source cells.
 rows=[]
 for p in fiscal:
  for geo in geos:
   a=get(ssid,p,geo,'Total','Paid sick leave hours');b=get(ssid,p,geo,'Total','Calculated FTEs')
   if not a or not b:continue
   value=a['value']/b['value'] if a['value'] is not None and b['value'] is not None and b['value']>0 else None
   item=dashrow(a,p,reference=f"{a['source_reference']} / {b['source_reference']}",status='Calculated' if value is not None else 'Unavailable',note='Paid sick leave hours divided by calculated FTEs; descriptive ratio.');item.update(value=value,unit='hours per calculated FTE');rows.append(item)
 views.append(view('Paid sick leave hours per calculated FTE','Hospital staffing',rows,'Calculated paid sick leave hours per FTE, using published CIHI totals. This ratio is a standardized descriptive measure; it does not measure individual absenteeism. Coverage may vary by year.',digits=1))
 for prof in PROFESSIONS:
  rows=[dashrow(r,p) for p in map(str,range(2020,2025)) for geo in GEO[1:] if (r:=get(osid,p,geo,prof,'Supply per 100,000'))]
  views.append(view(f'{prof} per 100,000 residents','Health professional supply',rows,'CIHI published supply density. Differences in registration, definitions and coverage matter. Asterisk values are retained with caution. These counts reflect supply, not necessarily active direct-care employment.',digits=1))
 # Recompute vacancy rate where all three measures are present; allowances for rounded estimates.
 ratechecks=0; maxdiff=0
 for r in records:
  if r['metric']=='Job vacancy rate' and r['value'] is not None:
   a=get(sid,r['period'],r['geography'],r['dimension'],'Job vacancies');b=get(sid,r['period'],r['geography'],r['dimension'],'Payroll employees')
   if a and b and a['value'] is not None and b['value'] is not None and a['value']+b['value']:
    diff=abs(r['value']-100*a['value']/(a['value']+b['value']));maxdiff=max(maxdiff,diff); assert diff<.25,(r,diff);ratechecks+=1
 otchecks=0; maxotdiff=0
 for r in staffing:
  if r['metric']!='Overtime rate' or r['value'] is None:continue
  a=get(ssid,r['period'],r['geography'],r['dimension'],'Overtime hours');b=get(ssid,r['period'],r['geography'],r['dimension'],'Regular worked hours')
  if a and b and a['value'] is not None and b['value'] is not None and a['value']+b['value']:
   diff=abs(r['value']-100*a['value']/(a['value']+b['value']));maxotdiff=max(maxotdiff,diff); assert diff<.03,(r,diff);otchecks+=1
 w=lambda geo,dim,metric:get(sid,last,geo,dim,metric)['value'];c=w('Canada','All industries','Job vacancies');h=w('Canada','Health care and social assistance','Job vacancies');mb=w('Manitoba','Health care and social assistance','Job vacancy rate');national=w('Canada','Health care and social assistance','Job vacancy rate');
 latest_staff=get(ssid,fiscal[-1],AGG,'Total','Overtime rate')['value'];mb_staff=get(ssid,fiscal[-1],'Manitoba','Total','Overtime rate');mb_staff=mb_staff['value'] if mb_staff else None
 findings=[f'In {last}, Canada reported {c:,.0f} vacancies across all industries. Health care and social assistance accounted for {h:,.0f}, or {h/c*100:.1f}% of the total (using published estimates).',f'Manitoba’s health care and social assistance vacancy rate was {mb:.1f}% in {last}, compared with {national:.1f}% nationally. These are unadjusted estimates for the same quarter.',f'Among CIHI reporting jurisdictions, overtime represented {latest_staff:.2f}% of regular plus overtime hospital worked hours in {fiscal[-1]}. Reporting coverage differs from the labour market survey.']
 p={'id':'workforce','title':'Canadian workforce and labour market analytics','category':'Workforce & operations','type':'real','group':'business','period':f'2020–2026 · latest periods vary','question':'Where are staffing pressures concentrated across Canadian industries and jurisdictions, and what can hospital staffing and health professional supply indicators add to workforce planning?','summary':'This project analyses quarterly vacancies, offered wages and payroll employment across selected industries and jurisdictions. Separate CIHI views examine hospital overtime, paid sick leave, calculated staffing capacity and health professional supply.','methods':['Source-linked extraction of Statistics Canada and CIHI aggregates','SQL comparisons across industries, regions and reporting periods','Reconciliation of published vacancy and overtime rates to source counts','Separate industry, hospital staffing and professional supply analyses'],'tools':['Python','SQL','Power BI project','Web dashboard'],'coverage':f'{len(records):,} source observations from Statistics Canada quarterly data (2021 Q1 to {last}), CIHI hospital staffing (2020–2021 to {fiscal[-1]}) and 2020–2024 professional supply. Regional labour market comparisons start in 2023.','source':'Statistics Canada Table 14-10-0442-01; CIHI Health Workforce Quick Stats and Overview','sourceUrl':SOURCES[files[0]][2],'repoUrl':'resources/workforce/workflow.zip','evidence':'resources/workforce/methodology.html','sourceLinks':[{'name':'CIHI hospital staffing and workforce','url':SOURCES[files[1]][2]},{'name':'CIHI health professional supply','url':SOURCES[files[2]][2]}],'statusText':'Real public aggregate statistics with original quality and suppression flags. Calculated ratios are clearly labelled. The survey and CIHI sources have different populations and reference periods.','limits':'Quarterly vacancy estimates are unadjusted for seasonality; compare the same quarter across years. Offered wages refer to vacant jobs and are expressed in nominal CAD. CIHI staffing excludes physician hours and Quebec and Nunavut do not report to CMDB. Coverage may change over time. CIHI supply estimates are not equivalent to employed FTEs, and the different source populations cannot establish a direct staffing shortfall.','findings':findings,'highlight':f'Canadian vacancies · {last}','highlightValue':f'{c:,.0f}','cards':[{'value':f'{c:,.0f}','label':f'Canada job vacancies · {last}'},{'value':f'{mb:.1f}%','label':f'Manitoba health and social assistance vacancy rate · {last}'},{'value':f'{latest_staff:.2f}%','label':f'Overtime among CIHI reporting jurisdictions · {fiscal[-1]}'}],'views':views}
 sql='''-- Separate grains and units: never sum wage/rate estimates or add overlapping sectors.\n-- Latest Canadian labour market snapshot, selected industries.\nSELECT dimension, metric, value, unit, status FROM observations\nWHERE source_file='workforce-statcan.zip' AND geography='Canada' AND period=(SELECT MAX(period) FROM observations WHERE source_file='workforce-statcan.zip')\nORDER BY dimension,metric;\n-- Same-quarter vacancy-rate comparison, 2025 versus 2026.\nWITH rates AS (SELECT geography, dimension, period, value FROM observations WHERE metric='Job vacancy rate' AND period IN ('2025 Q2','2026 Q2'))\nSELECT current.geography,current.dimension,ROUND(previous.value,1) AS rate_2025,ROUND(current.value,1) AS rate_2026,ROUND(current.value-previous.value,1) AS change_pp\nFROM rates current JOIN rates previous ON current.geography=previous.geography AND current.dimension=previous.dimension\nWHERE current.period='2026 Q2' AND previous.period='2025 Q2' AND current.value IS NOT NULL AND previous.value IS NOT NULL ORDER BY change_pp DESC;\n-- Paid sick leave hours per calculated hospital FTE, totals only.\nSELECT a.geography,a.period,ROUND(a.value/NULLIF(b.value,0),2) AS sick_hours_per_fte\nFROM observations a JOIN observations b ON a.source_id=b.source_id AND a.period=b.period AND a.geography=b.geography AND a.dimension=b.dimension\nWHERE a.metric='Paid sick leave hours' AND b.metric='Calculated FTEs' AND a.dimension='Total' AND a.value IS NOT NULL AND b.value>0 ORDER BY a.period,a.geography;\n-- Health supply density by selected profession and jurisdiction.\nSELECT geography,dimension,period,value,status FROM observations WHERE metric='Supply per 100,000' AND period='2024' ORDER BY dimension,geography;\n'''
 validation={'vacancy_formula_checks':ratechecks,'max_vacancy_rate_difference_pp':maxdiff,'overtime_formula_checks':otchecks,'max_overtime_rate_difference_pp':maxotdiff,'source_observations':len(records),'withheld':sum(r['value'] is None for r in records)}
 return p,records,sql,validation,files,[]

def forecast(y,method,h):
 if method=='Seasonal naive':return np.asarray([y[-12+i%12] for i in range(h)],dtype=float)
 # Fit log sales on deterministic trend and month indicators. No future target values.
 def design(t):
  return np.column_stack([np.ones(len(t)),t/12]+[(t%12==m).astype(float) for m in range(1,12)])
 t=np.arange(len(y));coef=np.linalg.lstsq(design(t),np.log(y),rcond=None)[0]
 return np.exp(design(np.arange(len(y),len(y)+h))@coef)
def make_months(start_yr,start_m,n):return [f'{start_yr+(start_m-1+i)//12:04d}-{(start_m-1+i)%12+1:02d}' for i in range(n)]
def score(actual,pred):return {'wape_percent':float(100*np.abs(actual-pred).sum()/np.abs(actual).sum()),'mae_cad_millions':float(np.mean(np.abs(actual-pred))/1000)}
def retail(raw,output):
 file='retail-statcan.zip';records=[]
 for r in stat_rows(raw,file):
  if r['GEO'] not in GEO or r[IND]!='Retail trade [44-45]' or r['Sales']!='Total retail sales':continue
  if r['Adjustments']=='Unadjusted' or (r['Adjustments']=='Seasonally adjusted' and r['REF_DATE']>='2025-10'):
   assert r['SCALAR_FACTOR']=='thousands';records.append(stat_record(file,r,r['REF_DATE'],r['Adjustments'],'Retail sales','CAD thousands'))
 idx=lookup(records);sid=SOURCES[file][0];dates=sorted({r['period'] for r in records if r['dimension']=='Unadjusted'});assert dates==make_months(2017,1,117); last=dates[-1];future=make_months(2026,10,6);predictions=[];scores=[];backtests=[];models=['Seasonal naive','Log trend + month effects']
 for geo in GEO:
  y=np.array([idx[(sid,p,geo,'Unadjusted','Retail sales')]['value'] for p in dates]);assert len(y)==117 and np.isfinite(y).all() and (y>0).all()
  # Four validation windows of six months, Oct 2023–Sep 2025, then two untouched holdout windows Oct 2025–Sep 2026.
  scores_geo={}
  for model in models:
   for phase,origins in [('Validation',[81,87,93,99]),('Holdout',[105,111])]:
    actual=np.concatenate([y[o:o+6] for o in origins]);pred=np.concatenate([forecast(y[:o],model,6) for o in origins]);s=score(actual,pred)
    scores_geo[(phase,model)]=s
    for o in origins:
     for k,predicted in enumerate(forecast(y[:o],model,6)):
      backtests.append({'geography':geo,'phase':phase,'model':model,'training_through':dates[o-1],'target_month':dates[o+k],'horizon_months':k+1,'actual_cad_thousands':y[o+k],'forecast_cad_thousands':predicted})
  selected=min(models,key=lambda m:scores_geo[('Validation',m)]['wape_percent']);
  for model in models:
   for phase in ('Validation','Holdout'):
    scores.append({'geography':geo,'phase':phase,'model':model,'selected':model==selected,**scores_geo[(phase,model)]})
  for m,v in zip(future,forecast(y,selected,6)):
   assert math.isfinite(v) and v>0;predictions.append({'geography':geo,'month':m,'model':selected,'forecast_cad_thousands':float(v),'training_through':last,'status':'Forecast'})
 views=[];rows=[]
 for geo in GEO:
  for period in dates[-24:]:
   row=idx[(sid,period,geo,'Unadjusted','Retail sales')];r=dashrow(row,geo,label=period,value=row['value']/1e6);r['unit']='CAD billions';rows.append(r)
  for pred in predictions:
   if pred['geography']!=geo:continue
   row=idx[(sid,last,geo,'Unadjusted','Retail sales')];r=dashrow(row,geo,label=pred['month'],value=pred['forecast_cad_thousands']/1e6,status='Forecast',reference=f"{pred['model']} · trained through {last}",note='Portfolio model using past published unadjusted sales. See workflow and holdout results.');r['unit']='CAD billions';rows.append(r)
 views.append(view('Monthly sales and six-month forecast (CAD billions)','Forecast and historical trends',rows,'Unadjusted nominal monthly sales. The teal line shows published observations; the dashed line shows portfolio-model forecasts for October 2026 to March 2027. Models are chosen using pre-holdout rolling-origin validation. Forecasts are point estimates, not official Statistics Canada predictions.',chart='line',digits=3,default='Canada'))
 rows=[]
 for p in dates[-12:]:
  for geo in GEO:
   if r:=idx.get((sid,p,geo,'Seasonally adjusted','Retail sales')):
    d=dashrow(r,p,value=r['value']/1e6 if r['value'] is not None else None);d['unit']='CAD billions';rows.append(d)
 views.append(view('Seasonally adjusted sales by jurisdiction (CAD billions)','Regional comparisons',rows,'Published seasonally adjusted monthly sales in current Canadian dollars. Canada is the separate benchmark; provincial/territorial values need not sum exactly to it because adjustment and rounding may differ.',digits=3))
 rows=[]
 for geo in GEO:
  for period in dates[-24:]:
   r=idx[(sid,period,geo,'Unadjusted','Retail sales')];d=dashrow(r,geo,label=period,value=r['value']/1e6);d['unit']='CAD billions';rows.append(d)
 views.append(view('Published unadjusted sales trend (CAD billions)','Forecast and historical trends',rows,'Unadjusted sales in nominal Canadian dollars. Month-to-month fluctuations include seasonal effects, so the next view compares the same month in prior years.',chart='line',digits=3,default='Canada'))
 # Seasonal index normalizes five full years within each geography: mean(month/annual mean)*100.
 rows=[];seasonal=[]
 for geo in GEO:
  vals=np.array([idx[(sid,p,geo,'Unadjusted','Retail sales')]['value'] for p in dates if '2021-01'<=p<='2025-12']).reshape(5,12);indices=(vals/vals.mean(axis=1,keepdims=True)).mean(axis=0)*100
  assert abs(indices.mean()-100)<1e-8
  src=idx[(sid,'2025-12',geo,'Unadjusted','Retail sales')]
  for i,val in enumerate(indices):
   month=date(2025,i+1,1).strftime('%b');seasonal.append({'geography':geo,'month':i+1,'seasonal_index':float(val)})
   d=dashrow(src,geo,label=month,value=float(val),status='Calculated',reference=f"{src['source_reference'].split(' · ')[0]} · 2021–2025");d['unit']='index (annual monthly mean = 100)';rows.append(d)
 views.append(view('Monthly seasonal sales index (average = 100)','Seasonality',rows,'Average of each month’s sales divided by its own year’s monthly mean, across five complete years (2021–2025). A value above 100 indicates a historically stronger-than-average month, not a growth rate.',digits=1,default='Canada'))
 # Negative YoY values need a true diverging bar renderer; include source references for both months.
 rows=[];yoy=[]
 for p in dates[-12:]:
  prior=f'{int(p[:4])-1:04d}-{p[5:]}'
  for geo in GEO:
   a=idx[(sid,p,geo,'Unadjusted','Retail sales')];b=idx[(sid,prior,geo,'Unadjusted','Retail sales')];v=100*(a['value']/b['value']-1);yoy.append({'geography':geo,'month':p,'yoy_percent':v,'current_cad_thousands':a['value'],'prior_cad_thousands':b['value']})
   d=dashrow(a,p,value=v,status='Calculated',reference=f"{a['source_reference']} / {b['period']}",note='Nominal same-month year-over-year percentage change.');d['unit']='percent';rows.append(d)
 views.append(view('Unadjusted retail sales year-over-year change (%)','Regional comparisons',rows,'Same-month year-over-year growth in nominal sales, calculated from unadjusted published sales. Negative values indicate contraction; positive values indicate growth.',digits=2))
 rows=[]
 for phase in ['Validation','Holdout']:
  for model in models:
   for m in scores:
    if m['phase']!=phase or m['model']!=model:continue
    src=idx[(sid,last,m['geography'],'Unadjusted','Retail sales')];d=dashrow(src,f'{phase} · {model}',value=m['wape_percent'],status='Calculated',reference=f"{model} · {phase} rolling-origin error",note='Weighted absolute percentage error; lower is better.');d['unit']='percent';rows.append(d)
 views.append(view('Model accuracy (WAPE, lower is better)','Model evaluation',rows,'WAPE = sum of absolute errors ÷ sum of actuals × 100. Validation uses four six-month rolling windows October 2023–September 2025; holdout uses two windows October 2025–September 2026. Model selection uses validation only; holdout estimates out-of-sample accuracy. Later windows train on actuals available at their origin.',digits=2,default='Holdout · Seasonal naive'))
 chosen=[m for m in scores if m['selected'] and m['phase']=='Holdout'];can=next(m for m in chosen if m['geography']=='Canada');canbaseline=next(m for m in scores if m['geography']=='Canada' and m['phase']=='Holdout' and m['model']=='Seasonal naive');canlatest=idx[(sid,last,'Canada','Seasonally adjusted','Retail sales')]['value']/1e6;mbforecast=next(p for p in predictions if p['geography']=='Manitoba' and p['month']==future[0]);peak=max([x for x in seasonal if x['geography']=='Canada'],key=lambda x:x['seasonal_index']);month=date(2025,peak['month'],1).strftime('%B')
 p={'id':'retail','title':'Canadian retail sales forecasting','category':'Commercial & predictive analytics','type':'real','group':'business','period':'2017–2026 actuals · 2026–2027 forecast','question':'How do Canadian retail sales vary by region and season, and how accurately can established time-series baselines forecast the next six months?','summary':'This project analyses monthly retail sales across Canada and all provinces and territories, quantifies regional growth and seasonal demand patterns, and tests two forecasting methods using rolling-origin validation before producing six-month forecasts.','methods':['Official monthly source extraction and quality flags','Time-series seasonality and year-over-year comparisons','Seasonal naive and log-linear seasonal trend models','Rolling-origin validation and separate holdout evaluation'],'tools':['Python','SQL','Tableau workbook','Web dashboard'],'coverage':f'{len(records):,} official observations; 117 unadjusted months per jurisdiction (January 2017 to September 2026) and the latest 12 seasonally adjusted months. Six-month forecasts for all 14 geographies, including Canada separately.','source':'Statistics Canada Monthly Retail Trade Survey, Table 20-10-0056-01','sourceUrl':SOURCES[file][2],'repoUrl':'resources/retail/workflow.zip','evidence':'resources/retail/methodology.html','statusText':'Published nominal retail sales, with separate unadjusted and seasonally adjusted series. Historical observations, derived measures and portfolio-model forecasts are labelled explicitly.','limits':'Nominal aggregate retail sales include price changes. These are broad market indicators, not individual store revenue or inventory demand. Model selection uses one historical release rather than first-release data vintages, so backtests do not establish real-time operational accuracy. Structural changes, economic shocks and revisions may affect forecasts. All future estimates are point forecasts without a probability interval.','findings':[f'Canada’s seasonally adjusted retail sales were ${canlatest:.2f} billion in September 2026.',f'For Canada, the validation-selected {can["model"]} model achieved holdout WAPE of {can["wape_percent"]:.2f}%; seasonal naive holdout WAPE was {canbaseline["wape_percent"]:.2f}%. Lower is better.',f'Across 2021–2025, {month} had the highest average national seasonal index ({peak["seasonal_index"]:.1f}). Manitoba’s October 2026 portfolio-model forecast was ${mbforecast["forecast_cad_thousands"]/1e6:.3f} billion.'],'highlight':f'Canada forecast holdout WAPE · {can["model"]}','highlightValue':f'{can["wape_percent"]:.2f}%','cards':[{'value':f'${canlatest:.2f}B','label':'Canada seasonally adjusted sales · Sep 2026'},{'value':f'{can["wape_percent"]:.2f}%','label':'Canada selected-model holdout WAPE'},{'value':'6 months','label':'Forecast horizon · Oct 2026–Mar 2027'}],'views':views}
 sql='''-- Retail data are nominal CAD thousands. Adjusted and unadjusted series remain separate.\nSELECT geography,period,ROUND(value/1000000,3) AS retail_cad_billions,status FROM observations WHERE dimension='Seasonally adjusted' AND period='2026-09' ORDER BY value DESC;\n-- Same-month YoY sales growth for September 2026.\nSELECT a.geography,a.period,ROUND((a.value/NULLIF(b.value,0)-1)*100,2) AS yoy_percent FROM observations a JOIN observations b ON a.geography=b.geography AND a.dimension=b.dimension AND a.metric=b.metric WHERE a.dimension='Unadjusted' AND a.period='2026-09' AND b.period='2025-09' ORDER BY yoy_percent DESC;\n-- Independently recompute holdout WAPE and MAE from predictions.\nSELECT geography,model,ROUND(100*SUM(ABS(actual_cad_thousands-forecast_cad_thousands))/SUM(ABS(actual_cad_thousands)),6) AS wape_percent,ROUND(AVG(ABS(actual_cad_thousands-forecast_cad_thousands))/1000,6) AS mae_cad_millions FROM backtest WHERE phase='Holdout' GROUP BY geography,model ORDER BY geography,wape_percent;\n-- Forecast records are intentionally separate from observed sales.\nSELECT geography,month,model,ROUND(forecast_cad_thousands/1000000,3) AS forecast_cad_billions,training_through FROM forecasts ORDER BY geography,month;\n'''
 validation={'source_observations':len(records),'geographies':len(GEO),'monthly_observations_per_geography':117,'validation_months':24,'holdout_months':12,'forecast_records':len(predictions),'backtest_records':len(backtests),'forecast_horizon_months':6,'selection':'Minimum validation WAPE, seasonal naive tie-break. Holdout excluded from selection.'}
 return p,records,sql,validation,[file],[('forecasts',predictions),('backtest',backtests),('model_scores',scores),('seasonality',seasonal),('yoy',yoy)]

def execute_sql(folder,sql,records,extras):
 conn=sqlite3.connect(':memory:');conn.row_factory=sqlite3.Row
 for name,rows in [('observations',records)]+extras:
  fields=list(rows[0]);types=['REAL' if any(isinstance(r[k],(float,int)) and not isinstance(r[k],bool) for r in rows) else 'TEXT' for k in fields]
  conn.execute('CREATE TABLE '+name+' ('+','.join(f'"{f}" {t}' for f,t in zip(fields,types))+')')
  conn.executemany('INSERT INTO '+name+' VALUES ('+','.join('?' for _ in fields)+')',[[r[k] for k in fields] for r in rows])
 statements=[q.strip() for q in sql.split(';') if any(line.strip() and not line.strip().startswith('--') for line in q.splitlines())]
 # Semicolons in explanatory SQL comments would be unsafe for simple splitting.
 result=[]
 for stmt in statements:
  result.append([dict(row) for row in conn.execute(stmt)])
 return result

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--raw-dir',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True);parser.add_argument('--project',choices=['workforce','retail','all'],default='all');parser.add_argument('--download',action='store_true');a=parser.parse_args()
 if a.download:
  a.raw_dir.mkdir(parents=True,exist_ok=True)
  needed=['workforce-statcan.zip','cihi-quickstats.xlsx','cihi-overview.xlsx'] if a.project=='workforce' else ['retail-statcan.zip'] if a.project=='retail' else list(SOURCES)
  for f in needed:
   if not (a.raw_dir/f).exists():
    with urlopen(Request(SOURCES[f][1],headers={'User-Agent':'Portfolio data analysis'}),timeout=120) as r:(a.raw_dir/f).write_bytes(r.read())
 for name,fn in [('workforce',workforce),('retail',retail)]:
  if a.project not in ('all',name):continue
  folder=a.output_dir/name;folder.mkdir(parents=True,exist_ok=True);p,records,sql,val,files,extras=fn(a.raw_dir,folder)
  write_csv(folder/'data.csv',records,FIELDS);save_json(folder/'source_manifest.json',source_manifest(a.raw_dir,files));save_json(folder/'validation.json',val)
  for title,rows in extras:write_csv(folder/(title+'.csv'),rows)
  (folder/'analysis.sql').write_text(sql);save_json(folder/'analysis_results.json',execute_sql(folder,sql,records,extras));save_json(folder/'project.json',p)
  print(name,'records',len(records),'views',len(p['views']),'combinations',sum(len(v['years']) for v in p['views']),'rows',sum(len(v['rows']) for v in p['views']),val,flush=True)
if __name__=='__main__':main()
