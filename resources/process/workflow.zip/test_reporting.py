"""Artificial fixtures used only for testing the reporting prototype."""

import unittest
import tempfile
import csv
from pathlib import Path
from reporting import generate, FIELDS


class ReportingTests(unittest.TestCase):
    def write(self, rows):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        file = Path(folder.name) / "test.csv"
        with file.open("w", newline="") as f:
            w = csv.writer(f)
            w.writerow(FIELDS)
            w.writerows(rows)
        return file

    def test_blank(self):
        result = generate(self.write([]))
        self.assertEqual(result["status"], "No data entered")
        self.assertIsNone(result["validation_rate_percent"])

    def test_valid_aggregate(self):
        result = generate(
            self.write(
                [["TEST A", "2025-01-01", 10, 8, 2, 20], ["TEST B", "2025-01-02", 5, 5, 0, 30]]
            )
        )
        self.assertEqual(result["records_received"], 15)
        self.assertEqual(result["validation_rate_percent"], 86.67)
        self.assertEqual(result["mean_report_preparation_minutes"], 25)

    def test_non_reconciled(self):
        with self.assertRaises(ValueError):
            generate(self.write([["TEST A", "2025-01-01", 10, 8, 3, 20]]))

    def test_duplicate(self):
        with self.assertRaises(ValueError):
            generate(
                self.write(
                    [["TEST A", "2025-01-01", 1, 1, 0, 5], ["TEST A", "2025-01-02", 2, 2, 0, 5]]
                )
            )

    def test_negative(self):
        with self.assertRaises(ValueError):
            generate(self.write([["TEST A", "2025-01-01", 1, 1, 0, -5]]))

    def test_nonfinite(self):
        with self.assertRaises(ValueError):
            generate(self.write([["TEST A", "2025-01-01", 1, 1, 0, "NaN"]]))

    def test_zero_denominator(self):
        result = generate(self.write([["TEST A", "2025-01-01", 0, 0, 0, 0]]))
        self.assertIsNone(result["validation_rate_percent"])

    def test_missing(self):
        with self.assertRaises(ValueError):
            generate(self.write([["TEST A", "2025-01-01", "", 1, 0, 20]]))

    def test_extra_values(self):
        with self.assertRaises(ValueError):
            generate(self.write([["TEST A", "2025-01-01", 1, 1, 0, 5, "extra"]]))

    def test_date_format(self):
        with self.assertRaises(ValueError):
            generate(self.write([["TEST A", "20250101", 1, 1, 0, 5]]))


if __name__ == "__main__":
    unittest.main()
