"""Generate a privacy-preserving reporting summary from aggregate cycle counts.
This is a portfolio prototype. It contains no actual participant records.
Use: python reporting.py aggregate_cycle_template.csv --output summary.json
"""

import argparse
import csv
import json
import math
from datetime import date
from pathlib import Path

FIELDS = [
    "cycle_id",
    "report_date",
    "records_received",
    "records_validated",
    "records_requiring_followup",
    "report_preparation_minutes",
]


def generate(source):
    seen = set()
    records = []
    with Path(source).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != FIELDS:
            raise ValueError("Use the exact template columns.")
        for number, row in enumerate(reader, 2):
            context = f"Row {number}"
            if None in row:
                raise ValueError(f"{context}: unexpected extra values.")
            if any(row.get(key) is None or not row[key].strip() for key in FIELDS):
                raise ValueError(f"{context}: every field is required.")
            cycle = row["cycle_id"].strip()
            if cycle in seen:
                raise ValueError(f"{context}: duplicate cycle ID.")
            seen.add(cycle)
            report_date = date.fromisoformat(row["report_date"])
            if report_date.isoformat() != row["report_date"]:
                raise ValueError(f"{context}: report date must use YYYY-MM-DD.")
            received = int(row["records_received"])
            validated = int(row["records_validated"])
            followup = int(row["records_requiring_followup"])
            minutes = float(row["report_preparation_minutes"])
            if min(received, validated, followup) < 0 or not math.isfinite(minutes) or minutes < 0:
                raise ValueError(f"{context}: numeric entries must be finite and nonnegative.")
            if validated + followup != received:
                raise ValueError(f"{context}: validated plus follow-up must equal received.")
            records.append(
                {
                    "received": received,
                    "validated": validated,
                    "followup": followup,
                    "minutes": minutes,
                    "date": report_date.isoformat(),
                }
            )
    if not records:
        return {
            "status": "No data entered",
            "reporting_cycles": 0,
            "records_received": None,
            "records_validated": None,
            "records_requiring_followup": None,
            "validation_rate_percent": None,
            "mean_report_preparation_minutes": None,
        }
    received = sum(row["received"] for row in records)
    validated = sum(row["validated"] for row in records)
    followup = sum(row["followup"] for row in records)
    assert validated + followup == received
    return {
        "status": "Validated",
        "reporting_cycles": len(records),
        "first_report_date": min(row["date"] for row in records),
        "last_report_date": max(row["date"] for row in records),
        "records_received": received,
        "records_validated": validated,
        "records_requiring_followup": followup,
        "validation_rate_percent": round(100 * validated / received, 2) if received else None,
        "mean_report_preparation_minutes": round(
            sum(row["minutes"] for row in records) / len(records), 2
        ),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, default=Path("summary.json"))
    args = parser.parse_args()
    try:
        summary = generate(args.input)
    except (ValueError, TypeError, OverflowError, OSError) as error:
        parser.exit(1, f"Validation failed: {error}\n")
    args.output.write_text(json.dumps(summary, indent=2) + "\n")
    print("Aggregate report:", summary["status"])


if __name__ == "__main__":
    main()
