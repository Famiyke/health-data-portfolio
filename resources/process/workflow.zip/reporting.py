"""Generate a privacy-preserving reporting summary from aggregate cycle counts.
This is a portfolio prototype. It contains no actual participant records.
Use: python reporting.py aggregate_cycle_template.csv --output summary.json
"""
import argparse,csv,json,math
from datetime import date
from pathlib import Path

FIELDS=['cycle_id','report_date','records_received','records_validated','records_requiring_followup','report_preparation_minutes']
COUNTS=FIELDS[2:5]

def generate(source):
    seen=set(); records=[]
    with Path(source).open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.DictReader(stream)
        if reader.fieldnames!=FIELDS:raise ValueError('Use the exact template columns.')
        for number,row in enumerate(reader,2):
            context=f'Row {number}'
            if any(row.get(key) is None or not row[key].strip() for key in FIELDS):raise ValueError(f'{context}: every field is required.')
            cycle=row['cycle_id'].strip()
            if cycle in seen:raise ValueError(f'{context}: duplicate cycle ID.')
            seen.add(cycle)
            report_date=date.fromisoformat(row['report_date'])
            values=[int(row[name]) for name in COUNTS]
            minutes=float(row['report_preparation_minutes'])
            if any(v<0 for v in values) or not math.isfinite(minutes) or minutes<0:raise ValueError(f'{context}: numeric entries must be finite and nonnegative.')
            if values[1]+values[2]!=values[0]:raise ValueError(f'{context}: validated plus follow-up must equal received.')
            records.append((*values,minutes,report_date.isoformat()))
    if not records:return {'status':'No data entered','reporting_cycles':0,'records_received':None,'records_validated':None,'records_requiring_followup':None,'validation_rate_percent':None,'mean_report_preparation_minutes':None}
    received,validated,followup=(sum(r[i] for r in records) for i in range(3));assert validated+followup==received
    return {'status':'Validated','reporting_cycles':len(records),'first_report_date':min(r[4] for r in records),'last_report_date':max(r[4] for r in records),'records_received':received,'records_validated':validated,'records_requiring_followup':followup,'validation_rate_percent':round(100*validated/received,2) if received else None,'mean_report_preparation_minutes':round(sum(r[3] for r in records)/len(records),2)}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('input',type=Path);parser.add_argument('--output',type=Path,default=Path('summary.json'));args=parser.parse_args()
    try:summary=generate(args.input)
    except (ValueError,TypeError,OverflowError,OSError) as error:parser.exit(1,f'Validation failed: {error}\n')
    args.output.write_text(json.dumps(summary,indent=2)+'\n');print('Aggregate report:',summary['status'])
if __name__=='__main__':main()
