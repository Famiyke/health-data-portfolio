"""Run the published SQL against the included CSV files in SQLite."""

import argparse
import csv
import json
import sqlite3
from contextlib import closing
from pathlib import Path

TABLES = {"contracts": "records.csv"}
NUMERIC_COLUMNS = {"source_record_index", "original_value_cents", "amendment_field_nonzero"}


def load_table(db, table, path):
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        columns = reader.fieldnames
        records = list(reader)
    column_types = [
        f'"{column}" ' + ("INTEGER" if column in NUMERIC_COLUMNS else "TEXT") for column in columns
    ]
    placeholders = ",".join("?" for _ in columns)
    values = []
    for record in records:
        row = []
        for column in columns:
            value = record[column]
            if column in NUMERIC_COLUMNS:
                value = int(value) if value else None
            row.append(value)
        values.append(row)
    db.execute(f"CREATE TABLE {table} ({','.join(column_types)})")
    db.executemany(f"INSERT INTO {table} VALUES ({placeholders})", values)


def run(folder):
    sql = (folder / "analysis.sql").read_text(encoding="utf-8")
    queries = [
        query.strip()
        for query in sql.split(";")
        if any(line.strip() and not line.strip().startswith("--") for line in query.splitlines())
    ]
    with closing(sqlite3.connect(":memory:")) as db:
        db.row_factory = sqlite3.Row
        for table, filename in TABLES.items():
            load_table(db, table, folder / filename)
        results = [[dict(row) for row in db.execute(query)] for query in queries]
    (folder / "analysis_results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("Executed", len(results), "SQL analyses")
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path, nargs="?", default=Path("."))
    run(parser.parse_args().folder)
