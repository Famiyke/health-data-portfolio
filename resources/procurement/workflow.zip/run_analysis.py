"""Execute the portfolio SQL against the included published-disclosure extract."""
from pathlib import Path
import csv,json,sqlite3,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
with (root/'records.csv').open(encoding='utf-8',newline='') as f:records=list(csv.DictReader(f))
fields=list(records[0]);numeric={'source_record_index','original_value_cents','amendment_field_nonzero'}
db=sqlite3.connect(':memory:');db.row_factory=sqlite3.Row
db.execute('CREATE TABLE contracts ('+','.join('"'+f+'" '+('INTEGER' if f in numeric else 'TEXT') for f in fields)+')')
db.executemany('INSERT INTO contracts VALUES ('+','.join('?' for _ in fields)+')',[[int(r[f]) if f in numeric else r[f] for f in fields] for r in records])
results=[[dict(r) for r in db.execute(q)] for q in (root/'analysis.sql').read_text().split(';') if any(l.strip() and not l.strip().startswith('--') for l in q.splitlines())]
(root/'analysis_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print('Executed',len(results),'SQL analyses')
