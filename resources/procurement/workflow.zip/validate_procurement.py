"""Reconcile every extract row to the official source CSV and verify dashboard aggregates.
Usage: python validate_procurement.py --raw-dir raw --output-dir output
"""

from pathlib import Path
from collections import Counter, defaultdict
from decimal import Decimal
import argparse
import csv
import hashlib
import json
import math
import statistics
import unicodedata

p = argparse.ArgumentParser()
p.add_argument("--raw-dir", type=Path, required=True)
p.add_argument("--output-dir", type=Path, required=True)
args = p.parse_args()
root = args.output_dir
raw = args.raw_dir / "contracts.csv"
manifest = json.loads((root / "source_manifest.json").read_text())
audit = json.loads((root / "validation.json").read_text())
project = json.loads((root / "project.json").read_text())
entities = manifest["scope"]["entities"]
periods = set(manifest["scope"]["reporting_periods"])
all_label = "Six selected entities"
h = hashlib.sha256()
with raw.open("rb") as f:
    for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
        h.update(chunk)
assert h.hexdigest() == manifest["source_sha256"]
assert raw.stat().st_size == manifest["source_bytes"]
with (root / "records.csv").open(newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
index = {int(r["source_record_index"]): r for r in rows}
assert len(index) == len(rows)
matched = 0
eligible = 0
group = defaultdict(list)
qgroup = defaultdict(list)
proc = {
    "AC": "Advance contract award notice",
    "OB": "Competitive · open bidding",
    "TC": "Competitive · traditional",
    "ST": "Competitive · selective",
    "TN": "Non-competitive",
}
commodity = {"C": "Construction", "G": "Goods", "S": "Services"}
with raw.open(encoding="utf-8-sig", newline="") as f:
    for i, r in enumerate(csv.DictReader(f), 1):
        if (
            r["owner_org"] not in entities
            or r["reporting_period"] not in periods
            or r["instrument_type"] != "C"
        ):
            continue
        try:
            amount = Decimal(r["original_value"])
            valid = (
                amount.is_finite()
                and amount > 10000
                and (amount * 100) == (amount * 100).to_integral_value()
            )
        except Exception:
            valid = False
        if not valid:
            continue
        eligible += 1
        assert i in index, i
        chosen = index[i]
        amount = int(amount * 100)
        vendor = " ".join(unicodedata.normalize("NFKC", r["vendor_name"]).upper().split())
        entity = entities[r["owner_org"]]
        period = r["reporting_period"]
        year = period[:9]
        route = proc.get(r["solicitation_procedure"], "Unknown")
        comm = commodity.get(r["commodity_type"], "Unknown")
        assert (
            chosen["reference_number"] == r["reference_number"]
            and chosen["procurement_id"] == r["procurement_id"]
            and chosen["owner_org"] == r["owner_org"]
            and chosen["entity"] == entity
            and chosen["supplier_group"] == vendor
            and chosen["reporting_period"] == period
            and chosen["fiscal_year"] == year
            and int(chosen["original_value_cents"]) == amount
            and chosen["solicitation"] == route
            and chosen["commodity"] == comm
        ), chosen
        matched += 1
        for e in (entity, all_label):
            group[(year, e)].append((amount, vendor, route, comm))
            qgroup[(period, e)].append(amount)
assert eligible == matched == len(rows) == audit["included_contract_disclosure_records"]
assert len({(r["owner_org"], r["reference_number"]) for r in rows}) == len(rows)
checks = 0
for v in project["views"]:
    for r in v["rows"]:
        title = v["name"]
        sel = r["year"]
        label = r["label"]
        if v["section"] == "Quarterly trends":
            values = qgroup[(label.replace(" Q", "-Q"), sel)]
            expected = sum(values) / 1e8 if "value" in title else len(values)
        else:
            y, e = (sel, label) if v["section"] == "Entity comparisons" else sel.split(" · ", 1)
            values = group[(y, e)]
            money = [x[0] for x in values]
            total = sum(money)
            vendors = Counter()
            routes = Counter()
            routecounts = Counter()
            commod = Counter()
            for amount, vendor, route, comm in values:
                vendors[vendor] += amount
                routes[route] += amount
                routecounts[route] += 1
                commod[comm] += amount
            if title.startswith("Original contract value"):
                expected = total / 1e8
            elif title.startswith("Contract disclosure"):
                expected = len(values)
            elif title.startswith("Median"):
                expected = statistics.median(money) / 1e5
            elif title.startswith("Distinct"):
                expected = len(vendors)
            elif title.startswith("Top five"):
                expected = 100 * sum(sorted(vendors.values(), reverse=True)[:5]) / total
            elif title.startswith("Non-competitive share of reported"):
                expected = 100 * routes["Non-competitive"] / total
            elif title.startswith("Non-competitive share of disclosure"):
                expected = 100 * routecounts["Non-competitive"] / len(values)
            elif title.startswith("Procurement route · original"):
                expected = routes[label] / 1e8
            elif title.startswith("Procurement route · disclosure"):
                expected = routecounts[label]
            elif title.startswith("Commodity"):
                expected = commod[label] / 1e8
            elif title.startswith("Top 10"):
                expected = vendors[label] / 1e8
                assert label in [
                    n for n, _ in sorted(vendors.items(), key=lambda x: (-x[1], x[0]))[:10]
                ]
            else:
                raise AssertionError(title)
        assert math.isclose(r["value"], expected, rel_tol=1e-10, abs_tol=1e-9), (
            title,
            sel,
            label,
            r["value"],
            expected,
        )
        checks += 1
results = json.loads((root / "analysis_results.json").read_text())
annual = results[0]
assert sum(r["disclosure_records"] for r in annual) == len(rows)
assert sum(r["original_value_cents"] for r in annual) == sum(
    int(x["original_value_cents"]) for x in rows
)
audit.update(
    status="passed",
    independently_matched_source_records=matched,
    independently_checked_dashboard_values=checks,
    aggregate_original_value_cents=sum(int(r["original_value_cents"]) for r in rows),
    sql_annual_reconciliation="passed",
)
(root / "validation.json").write_text(json.dumps(audit, indent=2) + "\n")
print(
    "PASS:",
    matched,
    "source records and",
    checks,
    "dashboard calculations; SQL totals reconcile exactly.",
)
