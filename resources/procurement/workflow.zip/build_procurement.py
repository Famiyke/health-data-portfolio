"""Build the federal procurement portfolio analysis from the public contracts CSV.
Download source using --download or supply the exact release in --raw-dir.
The contract value field for amended contracts is deliberately excluded from totals.
"""

from pathlib import Path
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from urllib.request import Request, urlopen
import argparse
import csv
import hashlib
import json
import statistics
import shutil
import unicodedata
from run_analysis import run as run_sql

SOURCE = "Government of Canada · Proactive Publication — Contracts"
URL = "https://open.canada.ca/data/en/dataset/d8f85d91-7dec-4fd1-8055-483b77225d8b"
DOWNLOAD = "https://open.canada.ca/data/dataset/d8f85d91-7dec-4fd1-8055-483b77225d8b/resource/fac950c0-00d5-4ec1-a4d3-9cbebf98a305/download/contracts.csv"
SCHEMA = "https://open.canada.ca/data/recombinant-published-schema/contracts.json"
ENTITIES = {
    "pwgsc-tpsgc": "Public Services and Procurement Canada",
    "esdc-edsc": "Employment and Social Development Canada",
    "hc-sc": "Health Canada",
    "phac-aspc": "Public Health Agency of Canada",
    "tc": "Transport Canada",
    "statcan": "Statistics Canada",
}
FY = ["2023-2024", "2024-2025", "2025-2026"]
PERIODS = [f"{y}-Q{q}" for y in FY for q in range(1, 5)]
PROCEDURES = {
    "AC": "Advance contract award notice",
    "OB": "Competitive · open bidding",
    "TC": "Competitive · traditional",
    "ST": "Competitive · selective",
    "TN": "Non-competitive",
}
COMMODITIES = {"G": "Goods", "S": "Services", "C": "Construction"}
ALL = "Six selected entities"
FIELDS = [
    "source_record_index",
    "reference_number",
    "procurement_id",
    "owner_org",
    "entity",
    "reporting_period",
    "fiscal_year",
    "supplier_group",
    "original_value_cents",
    "solicitation_code",
    "solicitation",
    "commodity_code",
    "commodity",
    "amendment_field_nonzero",
]


def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path, rows, fields=None):
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def cents(value):
    """Convert amounts to integer cents so contract totals stay exact."""
    try:
        amount = Decimal(value)
        if not amount.is_finite():
            return None
        amount_cents = amount * 100
        if amount_cents != amount_cents.to_integral_value():
            return None
        return int(amount_cents)
    except (InvalidOperation, ValueError):
        return None


def normalize(name):
    return " ".join(unicodedata.normalize("NFKC", name).upper().split())


def extract(source):
    audit = Counter()
    records = []
    seen = set()
    proc_ids = Counter()
    sha = hashlib.sha256()
    with source.open("rb") as file:
        while b := file.read(4 * 1024 * 1024):
            sha.update(b)
    with source.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        for i, row in enumerate(reader, 1):
            audit["total_source_records"] += 1
            if row["owner_org"] not in ENTITIES or row["reporting_period"] not in PERIODS:
                continue
            audit["selected_reporting_entity_and_period_records"] += 1
            if row["instrument_type"] != "C":
                audit["excluded_instrument_" + row["instrument_type"]] += 1
                continue
            value = cents(row["original_value"])
            if value is None:
                audit["invalid_original_value"] += 1
                continue
            if value <= 1000000:
                audit["original_value_at_or_below_10000"] += 1
                continue
            key = (row["owner_org"], row["reference_number"])
            assert key[1] and key not in seen, key
            seen.add(key)
            procurement_id = row["procurement_id"]
            proc_ids[(row["owner_org"], procurement_id)] += 1
            supplier = normalize(row["vendor_name"])
            assert supplier
            nonzero = cents(row["amendment_value"]) not in (None, 0)
            audit["included_nonzero_amendment_field"] += nonzero
            records.append(
                dict(
                    zip(
                        FIELDS,
                        [
                            i,
                            row["reference_number"],
                            procurement_id,
                            row["owner_org"],
                            ENTITIES[row["owner_org"]],
                            row["reporting_period"],
                            row["reporting_period"][:9],
                            supplier,
                            value,
                            row["solicitation_procedure"],
                            PROCEDURES.get(row["solicitation_procedure"], "Unknown"),
                            row["commodity_type"],
                            COMMODITIES.get(row["commodity_type"], "Unknown"),
                            int(nonzero),
                        ],
                    )
                )
            )
    audit["included_contract_disclosure_records"] = len(records)
    audit["additional_rows_with_repeated_procurement_id"] = sum(
        n - 1 for n in proc_ids.values() if n > 1
    )
    audit["unique_entity_reference_keys"] = len(seen)
    return records, dict(audit), sha.hexdigest()


SQL = Path(__file__).with_name("analysis.sql").read_text(encoding="utf-8")


def chartrow(sel, label, value, unit, ref, note=None):
    return {
        "year": sel,
        "label": label,
        "value": value,
        "unit": unit,
        "status": "Calculated from public records",
        "sourceId": SOURCE,
        "sourceRef": ref,
        "sourceUrl": URL,
        "n": ref,
        **({"note": note} if note else {}),
    }


def view(name, section, rows, explain, digits=1, chart="bar", default=None):
    years = list(dict.fromkeys(r["year"] for r in rows))
    return {
        "name": name,
        "section": section,
        "chart": chart,
        "digits": digits,
        "years": years,
        "defaultYear": default or years[-1],
        "rows": rows,
        "explain": explain,
        "denominatorLabel": "Reporting cohort / source reference",
    }


def summarize_group(group):
    values = [r["original_value_cents"] for r in group]
    total = sum(values)
    vendors = Counter()
    routes = Counter()
    routecounts = Counter()
    commod = Counter()
    commodcounts = Counter()
    for r in group:
        v = r["original_value_cents"]
        vendors[r["supplier_group"]] += v
        routes[r["solicitation"]] += v
        routecounts[r["solicitation"]] += 1
        commod[r["commodity"]] += v
        commodcounts[r["commodity"]] += 1
    top = sorted(vendors.items(), key=lambda pair: (-pair[1], pair[0]))
    return {
        "n": len(values),
        "total": total,
        "median": statistics.median(values),
        "supplier_count": len(vendors),
        "top5": 100 * sum(v for _, v in top[:5]) / total,
        "top": top,
        "routes": routes,
        "routecounts": routecounts,
        "commod": commod,
        "commodcounts": commodcounts,
        "noncompetitive_value": 100 * routes["Non-competitive"] / total,
        "noncompetitive_count": 100 * routecounts["Non-competitive"] / len(group),
    }


def summarize(records):
    annual = defaultdict(list)
    quarterly = defaultdict(list)
    for r in records:
        for entity in (r["entity"], ALL):
            annual[(r["fiscal_year"], entity)].append(r)
            quarterly[(r["reporting_period"], entity)].append(r)

    groups = {key: summarize_group(group) for key, group in annual.items()}
    views = []
    entities = list(ENTITIES.values())
    allentities = [ALL] + entities
    base = "Selected reporting entities, instrument C, original value above CAD $10,000. Original report values are summed in CAD, including taxes where reported and multi-year commitments. Amendments and standing-offer agreement rows are excluded. Reporting period is disclosure quarter, not service-delivery/payment period."
    annualmetrics = [
        (
            "Original contract value by entity (CAD millions)",
            "total",
            "CAD millions",
            2,
            lambda p: p["total"] / 100_000_000,
        ),
        ("Contract disclosure records by entity", "n", "records", 0, lambda p: p["n"]),
        (
            "Median original contract value by entity (CAD thousands)",
            "median",
            "CAD thousands",
            1,
            lambda p: p["median"] / 100_000,
        ),
        (
            "Distinct supplier-name groups by entity",
            "supplier_count",
            "supplier-name groups",
            0,
            lambda p: p["supplier_count"],
        ),
        (
            "Top five supplier-name groups · share of original value (%)",
            "top5",
            "percent",
            2,
            lambda p: p["top5"],
        ),
        (
            "Non-competitive share of reported original value (%)",
            "noncompetitive_value",
            "percent",
            2,
            lambda p: p["noncompetitive_value"],
        ),
        (
            "Non-competitive share of disclosure records (%)",
            "noncompetitive_count",
            "percent",
            2,
            lambda p: p["noncompetitive_count"],
        ),
    ]
    for title, key, unit, digits, fn in annualmetrics:
        rows = []
        for year in FY:
            for entity in entities:
                p = groups[(year, entity)]
                v = fn(p)
                ref = f'{year} · {entity} · {p["n"]:,} included records'
                rows.append(chartrow(year, entity, v, unit, ref))
        extra = (
            " Supplier names are case/whitespace-normalized strings, not verified common ownership."
            if "supplier" in title.lower()
            else (
                " Non-competitive refers to code TN. ACAN and other competitive routes are displayed separately."
                if "Non-competitive" in title
                else ""
            )
        )
        views.append(view(title, "Entity comparisons", rows, base + extra, digits))
    for metric, unit, digits, fn in [
        (
            "Quarterly original contract value (CAD millions)",
            "CAD millions",
            2,
            lambda p: p["total"] / 100_000_000,
        ),
        ("Quarterly disclosure records", "records", 0, lambda p: p["n"]),
    ]:
        rows = []
        for entity in allentities:
            for period in PERIODS:
                group = quarterly[(period, entity)]
                p = {"total": sum(r["original_value_cents"] for r in group), "n": len(group)}
                rows.append(
                    chartrow(
                        entity,
                        period.replace("-Q", " Q"),
                        fn(p),
                        unit,
                        f'{period} · {entity} · {p["n"]:,} included records',
                    )
                )
        views.append(view(metric, "Quarterly trends", rows, base, digits, "line", ALL))
    for title, key, labels, unit, digits, fn in [
        (
            "Procurement route · original value (CAD millions)",
            "routes",
            list(PROCEDURES.values()),
            "CAD millions",
            2,
            lambda x: x / 100_000_000,
        ),
        (
            "Procurement route · disclosure records",
            "routecounts",
            list(PROCEDURES.values()),
            "records",
            0,
            lambda x: x,
        ),
        (
            "Commodity · original value (CAD millions)",
            "commod",
            list(COMMODITIES.values()),
            "CAD millions",
            2,
            lambda x: x / 100_000_000,
        ),
    ]:
        rows = []
        for year in FY:
            for entity in allentities:
                p = groups[(year, entity)]
                selection = f"{year} · {entity}"
                for label in labels:
                    if label in p[key]:
                        rows.append(
                            chartrow(
                                selection,
                                label,
                                fn(p[key][label]),
                                unit,
                                f'{year} · {entity} · {p["n"]:,} cohort records',
                            )
                        )
        views.append(
            view(
                title,
                "Award mix",
                rows,
                base
                + " Categories retain source code meanings. ACAN is shown separately from competitive and non-competitive bidding.",
                digits,
                default=f"{FY[-1]} · {ALL}",
            )
        )
    rows = []
    for year in FY:
        for entity in allentities:
            p = groups[(year, entity)]
            selection = f"{year} · {entity}"
            for supplier, value in p["top"][:10]:
                rows.append(
                    chartrow(
                        selection,
                        supplier,
                        value / 100_000_000,
                        "CAD millions",
                        f"{year} · {entity} · published supplier name",
                        note="Normalized published vendor name, no fuzzy entity resolution.",
                    )
                )
    views.append(
        view(
            "Top 10 supplier-name groups by original value (CAD millions)",
            "Supplier concentration",
            rows,
            base
            + " Rank combines only exact normalized supplier-name matches. Different spellings or subsidiaries may represent the same legal group. Concentration is descriptive; it does not establish supplier risk or procurement compliance.",
            2,
            default=f"{FY[-1]} · {ALL}",
        )
    )
    latest = groups[(FY[-1], ALL)]
    largest = max(entities, key=lambda e: groups[(FY[-1], e)]["total"])
    largest_value = groups[(FY[-1], largest)]["total"] / 100_000_000
    v = latest["total"] / 100_000_000
    p = {
        "id": "procurement",
        "title": "Canadian federal procurement and supplier analytics",
        "category": "Procurement & financial operations",
        "type": "real",
        "group": "business",
        "period": "2023–2024 to 2025–2026 reporting years",
        "question": "How do disclosed contract award values, purchasing routes and supplier-name concentration vary across selected federal reporting entities?",
        "summary": "This project uses disclosed federal contract records to compare original award values, procurement methods and supplier-name concentration across six federal reporting entities and three complete fiscal reporting years.",
        "methods": [
            "Source-linked record extraction and exact integer-cent reconciliation",
            "SQL grouping by reporting quarter, entity, commodity and procurement route",
            "Supplier-name normalization and top-five share analysis",
            "Independent source and aggregate checks",
        ],
        "tools": ["Python", "SQL", "Web dashboard"],
        "coverage": f"{len(records):,} original contract disclosures above CAD $10,000 across six selected reporting entities, from 2023–2024 through 2025–2026. Includes contract call-ups classified C by the publisher.",
        "source": "Government of Canada · Proactive Publication of Contracts; Treasury Board of Canada Secretariat",
        "sourceUrl": URL,
        "repoUrl": "resources/procurement/workflow.zip",
        "evidence": "resources/procurement/methodology.html",
        "sourceLinks": [{"name": "Official data dictionary and schema", "url": SCHEMA}],
        "statusText": "Real public contract disclosure records. Original contract values are reported commitments, including multi-year amounts where applicable. Portfolio calculations use original award records only, with exact-cent totals and separate entity and reporting-quarter comparisons.",
        "limits": "The analysis is limited to six reporting entities and disclosed original award records above CAD $10,000. The source is unaudited, subject to revision and may vary in reporting practices. Original contract value is a commitment, not actual expenditure. Procurement IDs may repeat across separate disclosure rows. Supplier-name normalization does not establish legal ownership, and concentration or award route alone cannot establish misconduct, compliance or value for money.",
        "findings": [
            f'In {FY[-1]}, the six selected entities disclosed {latest["n"]:,} included original award records with a total original value of ${v:,.2f} million.',
            f"{largest} had the highest disclosed original value in {FY[-1]} among the selected entities (${largest_value:,.2f} million).",
            f'The five largest normalized supplier-name groups represented {latest["top5"]:.1f}% of the included original value in {FY[-1]}. Non-competitive code TN represented {latest["noncompetitive_count"]:.1f}% of disclosure records and {latest["noncompetitive_value"]:.1f}% of original value.',
        ],
        "highlight": f"Included original award disclosures · {FY[-1]}",
        "highlightValue": f'{latest["n"]:,}',
        "cards": [
            {"value": f"${v/1000:.2f}B", "label": f"Original disclosed value · {FY[-1]}"},
            {"value": f'{latest["n"]:,}', "label": f"Disclosure records · {FY[-1]}"},
            {
                "value": f'{latest["top5"]:.1f}%',
                "label": f"Top-five supplier-name value share · {FY[-1]}",
            },
        ],
        "views": views,
    }
    aggregates = []
    for v in views:
        for r in v["rows"]:
            aggregates.append(
                {
                    "indicator": v["name"],
                    "selection": r["year"],
                    "category": r["label"],
                    "value": r["value"],
                    "unit": r["unit"],
                    "source_reference": r["sourceRef"],
                }
            )
    return p, aggregates, groups


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--raw-dir", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--download", action="store_true")
    a = p.parse_args()
    a.raw_dir.mkdir(parents=True, exist_ok=True)
    a.output_dir.mkdir(parents=True, exist_ok=True)
    source = a.raw_dir / "contracts.csv"
    if a.download and not source.is_file():
        with urlopen(
            Request(DOWNLOAD, headers={"User-Agent": "Reproducible portfolio analysis"}),
            timeout=120,
        ) as response, source.open("wb") as f:
            shutil.copyfileobj(response, f, 4 * 1024 * 1024)
    records, audit, sha = extract(source)
    write_csv(a.output_dir / "records.csv", records, FIELDS)
    project, aggregates, _ = summarize(records)
    write_csv(a.output_dir / "aggregates.csv", aggregates)
    dump(a.output_dir / "project.json", project)
    (a.output_dir / "analysis.sql").write_text(SQL)
    run_sql(a.output_dir)
    dump(
        a.output_dir / "source_manifest.json",
        {
            "retrieved": "2026-11-23",
            "source_reference": URL,
            "source_download": DOWNLOAD,
            "source_schema": SCHEMA,
            "source_sha256": sha,
            "source_bytes": source.stat().st_size,
            "scope": {
                "entities": ENTITIES,
                "reporting_periods": PERIODS,
                "instrument_type": "C",
                "original_value_cad_greater_than": 10000,
            },
            "extraction_counts": audit,
        },
    )
    dump(a.output_dir / "validation.json", audit)
    print(
        "Records",
        len(records),
        "views",
        len(project["views"]),
        "selections",
        sum(len(v["years"]) for v in project["views"]),
    )
    print("\n".join(project["findings"]))


if __name__ == "__main__":
    main()
